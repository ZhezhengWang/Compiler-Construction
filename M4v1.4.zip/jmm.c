#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "jmm-types.h"
#include "symantic-analysis.h"

int strCount = 0;
int ifCount = 0;
int whileCount = 0;

int generateSystemCall(ASTNode *call);
void generateFunctions(ASTNode *root);
void generateTextSegment(ASTNode *root);
void generateFunctionDecl(ASTNode *decl);
void generateStatements(ASTNode* statements, SymTabScope *scope, ASTNode* parentWhile);
int generateLocalVariables(ASTNode* block, int localVarSize);
int generateStackFrame(ASTNode *formals, int localVarSize);
void generateStrings(ASTNode *c);
void generateGlobalVariables(ASTNode *c);
void generateDataSegment(ASTNode *root);
void generateFunctionCall(ASTNode *call, SymTabScope *scope);
void generateBreak(ASTNode *c, ASTNode* parentWhile);
void generateReturn(ASTNode *c, SymTabScope *scope);
void generateIf(ASTNode *c, SymTabScope *scope, ASTNode* parentWhile);
void generateIfElse(ASTNode *c, SymTabScope *scope, ASTNode* parentWhile);
void generateBinOperator(ASTNode *c, SymTabScope *scope);
void generateUnaryOperator(ASTNode *c, SymTabScope *scope);
void generateString(ASTNode *c);
void generateID(ASTNode *c, SymTabScope *scope);
void generateImmidiate(ASTNode *c);
void generateAssign(ASTNode *c, SymTabScope *scope);
void generateWhile(ASTNode *c, SymTabScope *scope);


/*
 *
 * Generates expressions recursively
 *
 */
void generateExpression(ASTNode* stmt, SymTabScope* scope, ASTNode* parentWhile)
{
  ASTNode* c = stmt;
  switch (c->astType)
  {
  case AST_FUNC_CALL:
    generateFunctionCall(c, scope);
    break;
  case AST_RETURN:
    generateReturn(c, scope);
    break;
  case AST_BREAK:
    generateBreak(c, parentWhile);
    break;
  case AST_IF:
    generateIf(c, scope, parentWhile);
    break;
  case AST_IF_ELSE:
    generateIfElse(c, scope, parentWhile);
    break;
  case AST_SUB:
  case AST_PLUS:
  case AST_MUL:
  case AST_DIV:
  case AST_MOD:
  case AST_LT:
  case AST_GT:
  case AST_LE:
  case AST_GE:
  case AST_EQ:
  case AST_NE:
  case AST_AND:
  case AST_OR:
    generateBinOperator(c, scope);
    break;
  case AST_NOT:
  case AST_USUB:
    generateUnaryOperator(c, scope);
    break;
  case AST_ID:
    generateID(c, scope);
    break;
  case AST_NUMBER:
  case AST_TRUE:
  case AST_FALSE:
    generateImmidiate(c);
    break;
  case AST_ASSIGN:
    generateAssign(c, scope);
    break;
  case AST_WHILE:
    generateWhile(c, scope);
    break;
  case AST_STRING:
    generateString(c);
    break;
  default:
    break;
  }
}

/*
 * Generate Data segment including string constants and global variables
 * - creates helper strings to print boolean variables
 * - Creates space to be used for the getcharacter system call
 * */
void generateDataSegment(ASTNode *root)
{
  printf("    .data\n");

  generateStrings(root);
  printf("__STRUE__: .asciiz \"true\"\n");
  printf("__SFALSE__: .asciiz \"false\"\n");
  printf("__getcharbuffer__: .space 2\n");

  generateGlobalVariables(root);

  printf("\n");
}

/*
 *
 * Traverse the parse tree and generate all global variables
 * */
void generateGlobalVariables(ASTNode *c)
{
  c = c->children;
  while (c)
  {
    if (c->astType == AST_GLOBAL_VAR_DECL)
    {
      printf("_%s:  .word 0\n", c->children->next->attr);
      c->label = (char*)malloc(32);
      sprintf(c->label, "_%s", c->children->next->attr);
    }
    c = c->next;
  }
}

/*
 * Helper function to escape special characters from a string constant before emitting it to the assembly
 * */
char *escapeChars(char *s)
{
  static char ret[4096];
  char *dst = ret;
  char *src = s;

  while (*src)
  {
    if (*src == '\n')
    {
      *dst++ = '\\';
      *dst++ = 'n';
      src++;
    } else if (*src == '\r')
    {
      *dst++ = '\\';
      *dst++ = 'r';
      src++;
    } else if (*src == '\t')
    {
      *dst++ = '\\';
      *dst++ = 't';
      src++;
    } else if (*src == '\\')
    {
      *dst++ = '\\';
      *dst++ = '\\';
      src++;
    } else if (*src < 32)
    {
      *dst++ = '\\';
      *dst++ = 'r';
      src++;
    } else
    {
      *dst++ = *src++;
    }
  }
  *dst = 0;
  return ret;
}

/* Traverse the parse tree recursivly and collect and generate all string constants */
void generateStrings(ASTNode *c)
{

  while (c)
  {
    if (c->astType == AST_STRING)
    {
      c->label = (char*) malloc(32);
      sprintf(c->label, "S%d", strCount++);
      printf("%s: .asciiz \"%s\"\n", c->label, escapeChars(c->attr));
    }
    generateStrings(c->children);
    c = c->next;
  }
}

/*
 * Generates the stack frame for a function by allocating space for return address, function base and local variables
 * */
int generateStackFrame(ASTNode *formals, int localVarSize)
{
  ASTNode *formal = formals->children;
  int index = 0;
  int parameterSize = 0;
  while (formal)
  {
    parameterSize += 4;
    formal = formal->next;
  }

  printf("    addi $sp, $sp, -%d\n", localVarSize + 8); // store return address
  printf("    sw $ra, 4($sp)\n"); // store return address
  printf("    sw $s0, 8($sp)\n"); // store previous function base
  printf("    move $s0, $sp\n"); // function base

  index = ( parameterSize+ localVarSize + 8 );

  formal = formals->children;
  while (formal)
  {
    formal->label = (char*) malloc(32);
    sprintf(formal->label, "%d($s0)", index);
    index -= 4;
    formal = formal->next;
  }

  return parameterSize;
}

/*
 * Generate labels for local variables relative to the function base
 * */
int generateLocalVariables(ASTNode* block, int localVarSize)
{
  ASTNode* statements = block->children;
  int index = localVarSize + 8;

  while (statements)
  {
    if (statements->astType == AST_VAR_DECL)
    {
      statements->label = (char*) malloc(32);
      sprintf(statements->label, "%d($s0)", index);
      index -= 4;
    }
    statements = statements->next;
  }

  return localVarSize;
}

/* Returns the space required to hold local variables of a function */
int getLocalVariablesSize(ASTNode* block)
{
  ASTNode* statements = block->children;
  int localVarSize = 0;

  while (statements)
  {
    if (statements->astType == AST_VAR_DECL)
    {
      localVarSize += 4;
    } else
    {
      break;
    }
    statements = statements->next;
  }

  return localVarSize;
}

/*
 * generate function declaration
 * */
void generateFunctionDecl(ASTNode *decl)
{
  SymTabScope *scope = decl->scope;
  ASTNode *retType = decl->children;
  ASTNode *id = retType->next;
  ASTNode *formals = id->next;
  ASTNode *block = formals->next;
  int localVarSize;

  char *name = id->attr;

  if (decl->astType == AST_MAIN_DECL) {
    printf("__main:\n");
    if (strcmp(name, "main") != 0)
      printf("%s:\n", name);
  } else {
    printf("%s:\n", name);
  }

  localVarSize = getLocalVariablesSize(block);
  generateStackFrame(formals, localVarSize);
  localVarSize = generateLocalVariables(block, localVarSize);

  generateStatements(block->children, scope, NULL);

  decl->label = (char*)malloc(32);

  printf("__funcEnd%s: \n", name);

  printf("    lw $ra, 4($sp)\n");
  printf("    lw $s0, 8($sp)\n");
  printf("    addi $sp, $sp, %d\n", localVarSize + 8);
  printf("    jr $ra\n\n");
}

/*
 * Checks if the current function call is a systemcall, if so, generate the code to call the systemcall
 * */

int generateSystemCall(ASTNode *call)
{
  ASTNode *call_id = call->children;
  char *name = call_id->attr;
  int found = 0;

  if (strcmp(name, "getchar") == 0)
  {
    printf("    jal __read_characterCaller\n");
    found = 1;
  } else if (strcmp(name, "halt") == 0)
  {
    printf("    li $v0, 10\n");
    printf("    syscall\n");
    found = 1;
  } else if (strcmp(name, "printb") == 0)
  {
    printf("    jal __printbCaller\n");
    found = 1;
  } else if (strcmp(name, "printc") == 0)
  {
    printf("    lw $a0, 4($sp)\n");
    printf("    li $v0, 11\n");
    printf("    syscall\n");
    found = 1;
  } else if (strcmp(name, "printi") == 0)
  {
    printf("    lw $a0, 4($sp)\n");
    printf("    li $v0, 1\n");
    printf("    syscall\n");
    found = 1;
  } else if (strcmp(name, "prints") == 0)
  {
    printf("    lw $a0, 4($sp)\n");
    printf("    li $v0, 4\n");
    printf("    syscall\n");
    found = 1;
  }
  return found;
}

/*
 * evaluate the actual parameters of a function and push them to stack to be used by the function
 * */
int generateActualParameters(ASTNode *actuals, SymTabScope *scope)
{
  ASTNode *actual = actuals->children;
  int count = 0;
  while (actual)
  {
    generateExpression(actual, scope, NULL);
    // Put the value in stack
    printf("    sw $v1, 0($sp)\n");
    printf("    addi $sp, $sp, -4\n");

    count++;
    actual = actual->next;
  }

  return count;
}

/*
 * Generate the function call, including evaluation of input parameters and stack cleanup
 * */
void generateFunctionCall(ASTNode *call, SymTabScope *scope)
{
  ASTNode *call_id = call->children;
  ASTNode *actuals = call_id->next;
  int pcount;
  char *name = call_id->attr;
  pcount = generateActualParameters(actuals, scope);
  if (!generateSystemCall(call))
  {
    printf("    jal %s\n", name);
  }
  printf("    addi $sp, $sp, %d\n", pcount * 4);
}

/* Generate break statement for the parent while  */
void generateBreak(ASTNode *c, ASTNode* parentWhile)
{
  printf("    b whileEnd%s\n", parentWhile->label);
}

/* Evaluate the return expression and jump to the end of function */
void generateReturn(ASTNode *c, SymTabScope *scope)
{
  if (c->children)
    generateExpression(c->children, scope, NULL);

  printf("    b __funcEnd%s\n", scope->name);
}

/* Generate the if statement including evaluation of the condition expression and the if body */
void generateIf(ASTNode *c, SymTabScope *scope, ASTNode* parentWhile)
{
  ASTNode *condExpr = c->children;
  ASTNode *ifBody = c->children->next;

  c->label = (char*) malloc(32);
  sprintf(c->label, "End%d", ifCount++);

  generateExpression(condExpr, scope, NULL);

  printf("    bnez $v1, ifshortbranch%s\n", c->label);
  printf("    j if%s\n", c->label);
  printf("ifshortbranch%s:\n", c->label);


  if (ifBody->astType == AST_BLOCK) {
    generateStatements(ifBody->children, scope, parentWhile);
  } else {
    generateStatements(ifBody, scope, parentWhile);
  }

  printf("if%s:\n", c->label);
}

/* Generate the ifelse statement including evaluation of the condition expression and the if and else bodies */
void generateIfElse(ASTNode *c, SymTabScope *scope, ASTNode* parentWhile)
{
  ASTNode *condExpr = c->children;
  ASTNode *ifBody = c->children->next;
  ASTNode *elseBody = ifBody->next;

  c->label = (char*) malloc(32);
  sprintf(c->label, "End%d", ifCount++);

  generateExpression(condExpr, scope, NULL);

  printf("    bnez $v1, ifelseshortbranch%s\n", c->label);
  printf("    j if%s\n", c->label);
  printf("ifelseshortbranch%s:\n", c->label);

  if (ifBody->astType == AST_BLOCK) {
    generateStatements(ifBody->children, scope, parentWhile);
  } else {
    generateStatements(ifBody, scope, parentWhile);
  }


  printf("    j else%s\n", c->label);
  printf("if%s:\n", c->label);

  if (elseBody->astType == AST_BLOCK) {
    generateStatements(elseBody->children, scope, parentWhile);
  } else {
    generateStatements(elseBody, scope, parentWhile);
  }

  printf("else%s:\n", c->label);

}

/* Helper function to check if the evaluation of the node requires a single instruction, use to decide wether to push the result to stack */
int needSingleInstruction(ASTNode *c) {
  switch(c->astType) {
    case AST_ID:
    case AST_NUMBER:
    case AST_TRUE:
    case AST_FALSE:
      return 1;
    default:
      return 0;
  }
  return 0;
}

/*
 * Generate code to evaluate a binaary expression recursivly evaluating the subtree.
 * */
void generateBinOperator(ASTNode *c, SymTabScope *scope)
{
  char *instruction;
  generateExpression(c->children->next, scope, NULL);

  if (needSingleInstruction(c->children)) {
    printf("    move $v0, $v1\n");
    generateExpression(c->children, scope, NULL);
  } else {
    printf("    sw $v1, 0($sp)\n");
    printf("    addi $sp, $sp, -4\n");
    generateExpression(c->children, scope, NULL);
    printf("    addi $sp, $sp, 4\n");
    printf("    lw $v0, 0($sp)\n");
  }

  switch (c->astType)
  {
  case AST_PLUS:
    instruction = "addu";
    break;
  case AST_SUB:
    instruction = "subu";
    break;
  case AST_MUL:
    instruction = "mul";
    break;
  case AST_DIV:
    instruction = "div";
    break;
  case AST_MOD:
    instruction = "rem";
    break;
  case AST_AND:
    instruction = "and";
    break;
  case AST_OR:
    instruction = "or";
    break;
  case AST_EQ:
    instruction = "seq";
    break;
  case AST_GE:
    instruction = "sge";
    break;
  case AST_GT:
    instruction = "sgt";
    break;
  case AST_LE:
    instruction = "sle";
    break;
  case AST_LT:
    instruction = "slt";
    break;
  case AST_NE:
    instruction = "sne";
    break;
  default:
    break;

  }

  printf("    %s $v1, $v1, $v0\n", instruction);

}

/*
 * Generate code to evaluate a unary expression recursivly evaluating the subtree.
 * */
void generateUnaryOperator(ASTNode *c, SymTabScope *scope)
{
  char *instruction;

  generateExpression(c->children, scope, NULL);

  switch (c->astType)
  {
  case AST_NOT:
    instruction = "not";
    break;
  case AST_USUB:
    instruction = "negu";
    break;

  default:
    break;

  }

  printf("    %s $v1, $v1\n", instruction);
  //if (c->astType == AST_NOT)
  //  printf("    andi $v1, $v1, 1\n");

}

/* Genetate code to load string address */
void generateString(ASTNode *c)
{
  printf("    la $v1, %s\n", c->label);
}


/* Genetate code to load a variable. */
void generateID(ASTNode *c, SymTabScope *scope)
{
  SymTabNode *s = lookupSymbol(c->attr, scope);

  /* If the variable is not of the same type, check if a global variable with the same type exists. */
  if (!s || s->type != c->expType)
  {
    s = lookupSymbol(c->attr, global);
  }

  ASTNode *decl = s->astNode;

  printf("    lw $v1, %s\n", decl->label);
}

/* Generate code to load an immidiate value */
void generateImmidiate(ASTNode *c)
{
  char *val;

  if (c->astType == AST_TRUE)
  {
    val = "1";
  } else if (c->astType == AST_FALSE)
  {
    val = "0";
  } else
  {
    val = c->attr;
  }

  printf("    li $v1, %s\n", val);
}

/* Generate code for the assignment expression evaluation */
void generateAssign(ASTNode *c, SymTabScope *scope)
{
  ASTNode *l = c->children;
  ASTNode *r = l->next;

  generateExpression(r, scope, NULL);
  SymTabNode *s = lookupSymbol(l->attr, scope);

  if (!s)
  {
    s = lookupSymbol(l->attr, global);
  }

  ASTNode *decl = s->astNode;

  printf("    sw $v1, %s\n", decl->label);
}

/* Generate code for while loop */
void generateWhile(ASTNode *c, SymTabScope *scope)
{
  ASTNode *condExpr = c->children;
  ASTNode *whileBody = c->children->next;

  c->label = (char*) malloc(32);
  sprintf(c->label, "%d", whileCount++);

  printf("whileBegin%s:\n", c->label);

  generateExpression(condExpr, scope, NULL);

  printf("    bnez $v1, whileshortbranch%s\n", c->label);
  printf("    j whileEnd%s\n", c->label);
  printf("whileshortbranch%s:\n", c->label);


  if (whileBody->astType == AST_BLOCK) {
    generateStatements(whileBody->children, scope, c);
  } else {
    generateStatements(whileBody, scope, c);
  }

  printf("    j whileBegin%s\n", c->label);

  printf("whileEnd%s:\n", c->label);

}

/* Generate code for the statements recursively. */
void generateStatements(ASTNode* stmts, SymTabScope *scope, ASTNode* parentWhile) {
    ASTNode *c = stmts;
    while (c) {
      if (c->astType == AST_STMT_EXPR) {
        generateExpression(c->children, scope, parentWhile);
      } else {
        generateExpression(c, scope, parentWhile);
      }
      c = c->next;
    }
}

/*
 * generate Helper functions for printb abd getcharacter systems calls
 * */
void generateSystemCallSupport() {
  printf("__printbCaller:\n");
  printf("    lw $a0, 4($sp)\n");
  printf("    beqz $a0, printbFalse\n");
  printf("    la $a0, __STRUE__\n");
  printf("    b printbEnd\n");
  printf("printbFalse:\n");
  printf("    la $a0, __SFALSE__\n");
  printf("printbEnd:\n");
  printf("    li $v0, 4\n");
  printf("    syscall\n");
  printf("    jr $ra\n\n");

  printf("__read_characterCaller:\n");
  printf("    li $v0, 8\n");
  printf("    la $a0, __getcharbuffer__\n");
  printf("    li $a1, 2\n");
  printf("    syscall\n");
  printf("    lb $v1, __getcharbuffer__\n");
  printf("    addiu $v0, $v1, -4\n");
  printf("    bnez $v0, __read_characterCallerEnd\n");
  printf("    li $v1, -1\n");
  printf("__read_characterCallerEnd:\n");
  printf("    jr $ra\n\n");


}

/* Generate start of text function including the main entry point */
void generateTextSegment(ASTNode *root) {
  printf("    .text\n");
  printf("    .globl main\n");
  printf("main:\n");
  printf("    jal __main\n");
  printf("    li $v0,10\n");
  printf("    syscall\n");
  generateSystemCallSupport();
  generateFunctions(root);
}

/* Generate all functions including their statements. */
void generateFunctions(ASTNode *root) {
    ASTNode *c = root->children;
    while (c) {
      if (c->astType == AST_MAIN_DECL || c->astType == AST_FUNC_DECL) {
        generateFunctionDecl(c);
      }
      c = c->next;
    }
}

/* Main function. Calls Lexical analyser, parser, symantic analyser and code generator in a linear fashion. */
int main(int argc, char *argv[])
{
    extern FILE *yyin;
    int ret;

    if (argc!=2) {
        fprintf(stderr,"command syntax: %s inputfile.c\n",argv[0]);
        return 1;
    }
    
    initSysCalls();
    
    yyin=fopen(argv[1],"r");
    
    ret = yyparse();   

    fclose(yyin);
    
    traverseParseTree(program, NULL, 1, 0, 0);
    if (!errorFlag) {
	    checkMainExists();
	    traverseParseTree(program, NULL, 2, 0, 0);
    }    


    if (!errorFlag) {
      generateDataSegment(program);
      generateTextSegment(program);
    }

    if (ret != 0)
        fprintf(stderr, "Errors encountered while parsing.\n");
    return ret || errorFlag;
}
