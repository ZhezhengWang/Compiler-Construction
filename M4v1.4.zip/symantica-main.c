#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "jmm-types.h"
#include "symantic-analysis.h"

/* Main function. Just calls yyparse */
int main(int argc, char *argv[])
{
    extern FILE *yyin;
    int ret;

    if (argc!=2) {
        fprintf(stderr,"command syntax: %s inputfile.c\n",argv[0]);
        return 1;
    }
    
    initSysCalls();
    
    yyin=fopen(argv[1],"r");
    
    ret = yyparse();   

    fclose(yyin);
    
    traverseParseTree(program, NULL, 1, 0, 0);
    if (!errorFlag) {
	    checkMainExists();
	    traverseParseTree(program, NULL, 2, 0, 0);
    }    


    if (!errorFlag) 
        printAST(program, 0);
    
    
    if (ret != 0)
        fprintf(stderr, "Errors encountered while parsing.\n");
    return ret || errorFlag;
}
