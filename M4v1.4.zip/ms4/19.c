
int A_0_0;
int A_0_1;
int A_0_2;
int A_0_3;
int A_0_4;
int A_0_5;
int A_0_6;
int A_0_7;
int A_0_8;
int A_0_9;
int A_1_0;
int A_1_1;
int A_1_2;
int A_1_3;
int A_1_4;
int A_1_5;
int A_1_6;
int A_1_7;
int A_1_8;
int A_1_9;
int A_2_0;
int A_2_1;
int A_2_2;
int A_2_3;
int A_2_4;
int A_2_5;
int A_2_6;
int A_2_7;
int A_2_8;
int A_2_9;
int A_3_0;
int A_3_1;
int A_3_2;
int A_3_3;
int A_3_4;
int A_3_5;
int A_3_6;
int A_3_7;
int A_3_8;
int A_3_9;
int A_4_0;
int A_4_1;
int A_4_2;
int A_4_3;
int A_4_4;
int A_4_5;
int A_4_6;
int A_4_7;
int A_4_8;
int A_4_9;
int A_5_0;
int A_5_1;
int A_5_2;
int A_5_3;
int A_5_4;
int A_5_5;
int A_5_6;
int A_5_7;
int A_5_8;
int A_5_9;
int A_6_0;
int A_6_1;
int A_6_2;
int A_6_3;
int A_6_4;
int A_6_5;
int A_6_6;
int A_6_7;
int A_6_8;
int A_6_9;
int A_7_0;
int A_7_1;
int A_7_2;
int A_7_3;
int A_7_4;
int A_7_5;
int A_7_6;
int A_7_7;
int A_7_8;
int A_7_9;
int A_8_0;
int A_8_1;
int A_8_2;
int A_8_3;
int A_8_4;
int A_8_5;
int A_8_6;
int A_8_7;
int A_8_8;
int A_8_9;
int A_9_0;
int A_9_1;
int A_9_2;
int A_9_3;
int A_9_4;
int A_9_5;
int A_9_6;
int A_9_7;
int A_9_8;
int A_9_9;
int not_there;
int T_0_0;
int T_0_1;
int T_0_2;
int T_0_3;
int T_0_4;
int T_0_5;
int T_0_6;
int T_0_7;
int T_0_8;
int T_0_9;
int T_1_0;
int T_1_1;
int T_1_2;
int T_1_3;
int T_1_4;
int T_1_5;
int T_1_6;
int T_1_7;
int T_1_8;
int T_1_9;
int T_2_0;
int T_2_1;
int T_2_2;
int T_2_3;
int T_2_4;
int T_2_5;
int T_2_6;
int T_2_7;
int T_2_8;
int T_2_9;
int T_3_0;
int T_3_1;
int T_3_2;
int T_3_3;
int T_3_4;
int T_3_5;
int T_3_6;
int T_3_7;
int T_3_8;
int T_3_9;
int T_4_0;
int T_4_1;
int T_4_2;
int T_4_3;
int T_4_4;
int T_4_5;
int T_4_6;
int T_4_7;
int T_4_8;
int T_4_9;
int T_5_0;
int T_5_1;
int T_5_2;
int T_5_3;
int T_5_4;
int T_5_5;
int T_5_6;
int T_5_7;
int T_5_8;
int T_5_9;
int T_6_0;
int T_6_1;
int T_6_2;
int T_6_3;
int T_6_4;
int T_6_5;
int T_6_6;
int T_6_7;
int T_6_8;
int T_6_9;
int T_7_0;
int T_7_1;
int T_7_2;
int T_7_3;
int T_7_4;
int T_7_5;
int T_7_6;
int T_7_7;
int T_7_8;
int T_7_9;
int T_8_0;
int T_8_1;
int T_8_2;
int T_8_3;
int T_8_4;
int T_8_5;
int T_8_6;
int T_8_7;
int T_8_8;
int T_8_9;
int T_9_0;
int T_9_1;
int T_9_2;
int T_9_3;
int T_9_4;
int T_9_5;
int T_9_6;
int T_9_7;
int T_9_8;
int T_9_9;
main()
{
  int i;
  int j;
  int x;
  int n;
  INTERNALseed(123);
  i = 0;
  while (i <= 9)
  {
    if (i == 0)
    {
      j = 0;
      while (j <= 9)
      {
        A_0_0 = morerandom() % 2;
        j = j + 1;
      }
    } else if (i == 1)
    {
      j = 0;
      while (j <= 9)
      {
        A_1_0 = morerandom() % 2;
        j = j + 1;
      }
    } else if (i == 2)
    {
      j = 0;
      while (j <= 9)
      {
        A_2_0 = morerandom() % 2;
        j = j + 1;
      }
    } else if (i == 3)
    {
      j = 0;
      while (j <= 9)
      {
        A_3_0 = morerandom() % 2;
        j = j + 1;
      }
    }
    i = i + 1;
  }
  x = 1;
  while (x <= 10)
  {
    i = 0;
    while (i <= 9)
    {
      if (i == 0)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 1)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 2)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 3)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 4)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 5)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 6)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 7)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 8)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 9)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      }
      n = neighbours(0, 1);
      i = i + 1;
    }
    i = 0;
    while (i <= 9)
    {
      if (i == 0)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 1)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 2)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 3)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 4)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 5)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 6)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 7)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 8)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      } else if (i == 9)
      {
        j = 0;
        while (j <= 9)
        {
          j = j + 1;
        }
      }
      i = i + 1;
    }
    printboard(x);
    x = x + 1;
  }
}
int neighbours(int y, int x)
{
  int n;
  n = 0;
  if (y == 0)
  {
    if (x == 0)
    {
      if (0 > 0)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (0 < 9)
        {
          n = n + not_there;
        }
      }
      if (0 > 0)
      {
        n = n + not_there;
      }
      if (0 < 9)
      {
        n = n + A_0_1;
      }
      if (0 < 9)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_1_0;
        if (0 < 9)
        {
          n = n + A_1_1;
        }
      }
    } else if (x == 1)
    {
      if (0 > 0)
      {
        if (1 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (1 < 9)
        {
          n = n + not_there;
        }
      }
      if (1 > 0)
      {
        n = n + A_0_0;
      }
      if (1 < 9)
      {
        n = n + A_0_2;
      }
      if (0 < 9)
      {
        if (1 > 0)
        {
          n = n + A_1_0;
        }
        n = n + A_1_1;
        if (1 < 9)
        {
          n = n + A_1_2;
        }
      }
    } else if (x == 2)
    {
      if (0 > 0)
      {
        if (2 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (2 < 9)
        {
          n = n + not_there;
        }
      }
      if (2 > 0)
      {
        n = n + A_0_1;
      }
      if (2 < 9)
      {
        n = n + A_0_3;
      }
      if (0 < 9)
      {
        if (2 > 0)
        {
          n = n + A_1_1;
        }
        n = n + A_1_2;
        if (2 < 9)
        {
          n = n + A_1_3;
        }
      }
    } else if (x == 3)
    {
      if (0 > 0)
      {
        if (3 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (3 < 9)
        {
          n = n + not_there;
        }
      }
      if (3 > 0)
      {
        n = n + A_0_2;
      }
      if (3 < 9)
      {
        n = n + A_0_4;
      }
      if (0 < 9)
      {
        if (3 > 0)
        {
          n = n + A_1_2;
        }
        n = n + A_1_3;
        if (3 < 9)
        {
          n = n + A_1_4;
        }
      }
    } else if (x == 4)
    {
      if (0 > 0)
      {
        if (4 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (4 < 9)
        {
          n = n + not_there;
        }
      }
      if (4 > 0)
      {
        n = n + A_0_3;
      }
      if (4 < 9)
      {
        n = n + A_0_5;
      }
      if (0 < 9)
      {
        if (4 > 0)
        {
          n = n + A_1_3;
        }
        n = n + A_1_4;
        if (4 < 9)
        {
          n = n + A_1_5;
        }
      }
    } else if (x == 5)
    {
      if (0 > 0)
      {
        if (5 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (5 < 9)
        {
          n = n + not_there;
        }
      }
      if (5 > 0)
      {
        n = n + A_0_4;
      }
      if (5 < 9)
      {
        n = n + A_0_6;
      }
      if (0 < 9)
      {
        if (5 > 0)
        {
          n = n + A_1_4;
        }
        n = n + A_1_5;
        if (5 < 9)
        {
          n = n + A_1_6;
        }
      }
    } else if (x == 6)
    {
      if (0 > 0)
      {
        if (6 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (6 < 9)
        {
          n = n + not_there;
        }
      }
      if (6 > 0)
      {
        n = n + A_0_5;
      }
      if (6 < 9)
      {
        n = n + A_0_7;
      }
      if (0 < 9)
      {
        if (6 > 0)
        {
          n = n + A_1_5;
        }
        n = n + A_1_6;
        if (6 < 9)
        {
          n = n + A_1_7;
        }
      }
    } else if (x == 7)
    {
      if (0 > 0)
      {
        if (7 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (7 < 9)
        {
          n = n + not_there;
        }
      }
      if (7 > 0)
      {
        n = n + A_0_6;
      }
      if (7 < 9)
      {
        n = n + A_0_8;
      }
      if (0 < 9)
      {
        if (7 > 0)
        {
          n = n + A_1_6;
        }
        n = n + A_1_7;
        if (7 < 9)
        {
          n = n + A_1_8;
        }
      }
    } else if (x == 8)
    {
      if (0 > 0)
      {
        if (8 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (8 < 9)
        {
          n = n + not_there;
        }
      }
      if (8 > 0)
      {
        n = n + A_0_7;
      }
      if (8 < 9)
      {
        n = n + A_0_9;
      }
      if (0 < 9)
      {
        if (8 > 0)
        {
          n = n + A_1_7;
        }
        n = n + A_1_8;
        if (8 < 9)
        {
          n = n + A_1_9;
        }
      }
    } else if (x == 9)
    {
      if (0 > 0)
      {
        if (9 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
      if (9 > 0)
      {
        n = n + A_0_8;
      }
      if (9 < 9)
      {
        n = n + not_there;
      }
      if (0 < 9)
      {
        if (9 > 0)
        {
          n = n + A_1_8;
        }
        n = n + A_1_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
    }
  } else if (y == 1)
  {
    if (x == 0)
    {
      if (1 > 0)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_0_0;
        if (0 < 9)
        {
          n = n + A_0_1;
        }
      }
      if (0 > 0)
      {
        n = n + not_there;
      }
      if (0 < 9)
      {
        n = n + A_1_1;
      }
      if (1 < 9)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_2_0;
        if (0 < 9)
        {
          n = n + A_2_1;
        }
      }
    } else if (x == 1)
    {
      if (1 > 0)
      {
        if (1 > 0)
        {
          n = n + A_0_0;
        }
        n = n + A_0_1;
        if (1 < 9)
        {
          n = n + A_0_2;
        }
      }
      if (1 > 0)
      {
        n = n + A_1_0;
      }
      if (1 < 9)
      {
        n = n + A_1_2;
      }
      if (1 < 9)
      {
        if (1 > 0)
        {
          n = n + A_2_0;
        }
        n = n + A_2_1;
        if (1 < 9)
        {
          n = n + A_2_2;
        }
      }
    } else if (x == 2)
    {
      if (1 > 0)
      {
        if (2 > 0)
        {
          n = n + A_0_1;
        }
        n = n + A_0_2;
        if (2 < 9)
        {
          n = n + A_0_3;
        }
      }
      if (2 > 0)
      {
        n = n + A_1_1;
      }
      if (2 < 9)
      {
        n = n + A_1_3;
      }
      if (1 < 9)
      {
        if (2 > 0)
        {
          n = n + A_2_1;
        }
        n = n + A_2_2;
        if (2 < 9)
        {
          n = n + A_2_3;
        }
      }
    } else if (x == 3)
    {
      if (1 > 0)
      {
        if (3 > 0)
        {
          n = n + A_0_2;
        }
        n = n + A_0_3;
        if (3 < 9)
        {
          n = n + A_0_4;
        }
      }
      if (3 > 0)
      {
        n = n + A_1_2;
      }
      if (3 < 9)
      {
        n = n + A_1_4;
      }
      if (1 < 9)
      {
        if (3 > 0)
        {
          n = n + A_2_2;
        }
        n = n + A_2_3;
        if (3 < 9)
        {
          n = n + A_2_4;
        }
      }
    } else if (x == 4)
    {
      if (1 > 0)
      {
        if (4 > 0)
        {
          n = n + A_0_3;
        }
        n = n + A_0_4;
        if (4 < 9)
        {
          n = n + A_0_5;
        }
      }
      if (4 > 0)
      {
        n = n + A_1_3;
      }
      if (4 < 9)
      {
        n = n + A_1_5;
      }
      if (1 < 9)
      {
        if (4 > 0)
        {
          n = n + A_2_3;
        }
        n = n + A_2_4;
        if (4 < 9)
        {
          n = n + A_2_5;
        }
      }
    } else if (x == 5)
    {
      if (1 > 0)
      {
        if (5 > 0)
        {
          n = n + A_0_4;
        }
        n = n + A_0_5;
        if (5 < 9)
        {
          n = n + A_0_6;
        }
      }
      if (5 > 0)
      {
        n = n + A_1_4;
      }
      if (5 < 9)
      {
        n = n + A_1_6;
      }
      if (1 < 9)
      {
        if (5 > 0)
        {
          n = n + A_2_4;
        }
        n = n + A_2_5;
        if (5 < 9)
        {
          n = n + A_2_6;
        }
      }
    } else if (x == 6)
    {
      if (1 > 0)
      {
        if (6 > 0)
        {
          n = n + A_0_5;
        }
        n = n + A_0_6;
        if (6 < 9)
        {
          n = n + A_0_7;
        }
      }
      if (6 > 0)
      {
        n = n + A_1_5;
      }
      if (6 < 9)
      {
        n = n + A_1_7;
      }
      if (1 < 9)
      {
        if (6 > 0)
        {
          n = n + A_2_5;
        }
        n = n + A_2_6;
        if (6 < 9)
        {
          n = n + A_2_7;
        }
      }
    } else if (x == 7)
    {
      if (1 > 0)
      {
        if (7 > 0)
        {
          n = n + A_0_6;
        }
        n = n + A_0_7;
        if (7 < 9)
        {
          n = n + A_0_8;
        }
      }
      if (7 > 0)
      {
        n = n + A_1_6;
      }
      if (7 < 9)
      {
        n = n + A_1_8;
      }
      if (1 < 9)
      {
        if (7 > 0)
        {
          n = n + A_2_6;
        }
        n = n + A_2_7;
        if (7 < 9)
        {
          n = n + A_2_8;
        }
      }
    } else if (x == 8)
    {
      if (1 > 0)
      {
        if (8 > 0)
        {
          n = n + A_0_7;
        }
        n = n + A_0_8;
        if (8 < 9)
        {
          n = n + A_0_9;
        }
      }
      if (8 > 0)
      {
        n = n + A_1_7;
      }
      if (8 < 9)
      {
        n = n + A_1_9;
      }
      if (1 < 9)
      {
        if (8 > 0)
        {
          n = n + A_2_7;
        }
        n = n + A_2_8;
        if (8 < 9)
        {
          n = n + A_2_9;
        }
      }
    } else if (x == 9)
    {
      if (1 > 0)
      {
        if (9 > 0)
        {
          n = n + A_0_8;
        }
        n = n + A_0_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
      if (9 > 0)
      {
        n = n + A_1_8;
      }
      if (9 < 9)
      {
        n = n + not_there;
      }
      if (1 < 9)
      {
        if (9 > 0)
        {
          n = n + A_2_8;
        }
        n = n + A_2_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
    }
  } else if (y == 2)
  {
    if (x == 0)
    {
      if (2 > 0)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_1_0;
        if (0 < 9)
        {
          n = n + A_1_1;
        }
      }
      if (0 > 0)
      {
        n = n + not_there;
      }
      if (0 < 9)
      {
        n = n + A_2_1;
      }
      if (2 < 9)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_3_0;
        if (0 < 9)
        {
          n = n + A_3_1;
        }
      }
    } else if (x == 1)
    {
      if (2 > 0)
      {
        if (1 > 0)
        {
          n = n + A_1_0;
        }
        n = n + A_1_1;
        if (1 < 9)
        {
          n = n + A_1_2;
        }
      }
      if (1 > 0)
      {
        n = n + A_2_0;
      }
      if (1 < 9)
      {
        n = n + A_2_2;
      }
      if (2 < 9)
      {
        if (1 > 0)
        {
          n = n + A_3_0;
        }
        n = n + A_3_1;
        if (1 < 9)
        {
          n = n + A_3_2;
        }
      }
    } else if (x == 2)
    {
      if (2 > 0)
      {
        if (2 > 0)
        {
          n = n + A_1_1;
        }
        n = n + A_1_2;
        if (2 < 9)
        {
          n = n + A_1_3;
        }
      }
      if (2 > 0)
      {
        n = n + A_2_1;
      }
      if (2 < 9)
      {
        n = n + A_2_3;
      }
      if (2 < 9)
      {
        if (2 > 0)
        {
          n = n + A_3_1;
        }
        n = n + A_3_2;
        if (2 < 9)
        {
          n = n + A_3_3;
        }
      }
    } else if (x == 3)
    {
      if (2 > 0)
      {
        if (3 > 0)
        {
          n = n + A_1_2;
        }
        n = n + A_1_3;
        if (3 < 9)
        {
          n = n + A_1_4;
        }
      }
      if (3 > 0)
      {
        n = n + A_2_2;
      }
      if (3 < 9)
      {
        n = n + A_2_4;
      }
      if (2 < 9)
      {
        if (3 > 0)
        {
          n = n + A_3_2;
        }
        n = n + A_3_3;
        if (3 < 9)
        {
          n = n + A_3_4;
        }
      }
    } else if (x == 4)
    {
      if (2 > 0)
      {
        if (4 > 0)
        {
          n = n + A_1_3;
        }
        n = n + A_1_4;
        if (4 < 9)
        {
          n = n + A_1_5;
        }
      }
      if (4 > 0)
      {
        n = n + A_2_3;
      }
      if (4 < 9)
      {
        n = n + A_2_5;
      }
      if (2 < 9)
      {
        if (4 > 0)
        {
          n = n + A_3_3;
        }
        n = n + A_3_4;
        if (4 < 9)
        {
          n = n + A_3_5;
        }
      }
    } else if (x == 5)
    {
      if (2 > 0)
      {
        if (5 > 0)
        {
          n = n + A_1_4;
        }
        n = n + A_1_5;
        if (5 < 9)
        {
          n = n + A_1_6;
        }
      }
      if (5 > 0)
      {
        n = n + A_2_4;
      }
      if (5 < 9)
      {
        n = n + A_2_6;
      }
      if (2 < 9)
      {
        if (5 > 0)
        {
          n = n + A_3_4;
        }
        n = n + A_3_5;
        if (5 < 9)
        {
          n = n + A_3_6;
        }
      }
    } else if (x == 6)
    {
      if (2 > 0)
      {
        if (6 > 0)
        {
          n = n + A_1_5;
        }
        n = n + A_1_6;
        if (6 < 9)
        {
          n = n + A_1_7;
        }
      }
      if (6 > 0)
      {
        n = n + A_2_5;
      }
      if (6 < 9)
      {
        n = n + A_2_7;
      }
      if (2 < 9)
      {
        if (6 > 0)
        {
          n = n + A_3_5;
        }
        n = n + A_3_6;
        if (6 < 9)
        {
          n = n + A_3_7;
        }
      }
    } else if (x == 7)
    {
      if (2 > 0)
      {
        if (7 > 0)
        {
          n = n + A_1_6;
        }
        n = n + A_1_7;
        if (7 < 9)
        {
          n = n + A_1_8;
        }
      }
      if (7 > 0)
      {
        n = n + A_2_6;
      }
      if (7 < 9)
      {
        n = n + A_2_8;
      }
      if (2 < 9)
      {
        if (7 > 0)
        {
          n = n + A_3_6;
        }
        n = n + A_3_7;
        if (7 < 9)
        {
          n = n + A_3_8;
        }
      }
    } else if (x == 8)
    {
      if (2 > 0)
      {
        if (8 > 0)
        {
          n = n + A_1_7;
        }
        n = n + A_1_8;
        if (8 < 9)
        {
          n = n + A_1_9;
        }
      }
      if (8 > 0)
      {
        n = n + A_2_7;
      }
      if (8 < 9)
      {
        n = n + A_2_9;
      }
      if (2 < 9)
      {
        if (8 > 0)
        {
          n = n + A_3_7;
        }
        n = n + A_3_8;
        if (8 < 9)
        {
          n = n + A_3_9;
        }
      }
    } else if (x == 9)
    {
      if (2 > 0)
      {
        if (9 > 0)
        {
          n = n + A_1_8;
        }
        n = n + A_1_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
      if (9 > 0)
      {
        n = n + A_2_8;
      }
      if (9 < 9)
      {
        n = n + not_there;
      }
      if (2 < 9)
      {
        if (9 > 0)
        {
          n = n + A_3_8;
        }
        n = n + A_3_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
    }
  } else if (y == 3)
  {
    if (x == 0)
    {
      if (3 > 0)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_2_0;
        if (0 < 9)
        {
          n = n + A_2_1;
        }
      }
      if (0 > 0)
      {
        n = n + not_there;
      }
      if (0 < 9)
      {
        n = n + A_3_1;
      }
      if (3 < 9)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_4_0;
        if (0 < 9)
        {
          n = n + A_4_1;
        }
      }
    } else if (x == 1)
    {
      if (3 > 0)
      {
        if (1 > 0)
        {
          n = n + A_2_0;
        }
        n = n + A_2_1;
        if (1 < 9)
        {
          n = n + A_2_2;
        }
      }
      if (1 > 0)
      {
        n = n + A_3_0;
      }
      if (1 < 9)
      {
        n = n + A_3_2;
      }
      if (3 < 9)
      {
        if (1 > 0)
        {
          n = n + A_4_0;
        }
        n = n + A_4_1;
        if (1 < 9)
        {
          n = n + A_4_2;
        }
      }
    } else if (x == 2)
    {
      if (3 > 0)
      {
        if (2 > 0)
        {
          n = n + A_2_1;
        }
        n = n + A_2_2;
        if (2 < 9)
        {
          n = n + A_2_3;
        }
      }
      if (2 > 0)
      {
        n = n + A_3_1;
      }
      if (2 < 9)
      {
        n = n + A_3_3;
      }
      if (3 < 9)
      {
        if (2 > 0)
        {
          n = n + A_4_1;
        }
        n = n + A_4_2;
        if (2 < 9)
        {
          n = n + A_4_3;
        }
      }
    } else if (x == 3)
    {
      if (3 > 0)
      {
        if (3 > 0)
        {
          n = n + A_2_2;
        }
        n = n + A_2_3;
        if (3 < 9)
        {
          n = n + A_2_4;
        }
      }
      if (3 > 0)
      {
        n = n + A_3_2;
      }
      if (3 < 9)
      {
        n = n + A_3_4;
      }
      if (3 < 9)
      {
        if (3 > 0)
        {
          n = n + A_4_2;
        }
        n = n + A_4_3;
        if (3 < 9)
        {
          n = n + A_4_4;
        }
      }
    } else if (x == 4)
    {
      if (3 > 0)
      {
        if (4 > 0)
        {
          n = n + A_2_3;
        }
        n = n + A_2_4;
        if (4 < 9)
        {
          n = n + A_2_5;
        }
      }
      if (4 > 0)
      {
        n = n + A_3_3;
      }
      if (4 < 9)
      {
        n = n + A_3_5;
      }
      if (3 < 9)
      {
        if (4 > 0)
        {
          n = n + A_4_3;
        }
        n = n + A_4_4;
        if (4 < 9)
        {
          n = n + A_4_5;
        }
      }
    } else if (x == 5)
    {
      if (3 > 0)
      {
        if (5 > 0)
        {
          n = n + A_2_4;
        }
        n = n + A_2_5;
        if (5 < 9)
        {
          n = n + A_2_6;
        }
      }
      if (5 > 0)
      {
        n = n + A_3_4;
      }
      if (5 < 9)
      {
        n = n + A_3_6;
      }
      if (3 < 9)
      {
        if (5 > 0)
        {
          n = n + A_4_4;
        }
        n = n + A_4_5;
        if (5 < 9)
        {
          n = n + A_4_6;
        }
      }
    } else if (x == 6)
    {
      if (3 > 0)
      {
        if (6 > 0)
        {
          n = n + A_2_5;
        }
        n = n + A_2_6;
        if (6 < 9)
        {
          n = n + A_2_7;
        }
      }
      if (6 > 0)
      {
        n = n + A_3_5;
      }
      if (6 < 9)
      {
        n = n + A_3_7;
      }
      if (3 < 9)
      {
        if (6 > 0)
        {
          n = n + A_4_5;
        }
        n = n + A_4_6;
        if (6 < 9)
        {
          n = n + A_4_7;
        }
      }
    } else if (x == 7)
    {
      if (3 > 0)
      {
        if (7 > 0)
        {
          n = n + A_2_6;
        }
        n = n + A_2_7;
        if (7 < 9)
        {
          n = n + A_2_8;
        }
      }
      if (7 > 0)
      {
        n = n + A_3_6;
      }
      if (7 < 9)
      {
        n = n + A_3_8;
      }
      if (3 < 9)
      {
        if (7 > 0)
        {
          n = n + A_4_6;
        }
        n = n + A_4_7;
        if (7 < 9)
        {
          n = n + A_4_8;
        }
      }
    } else if (x == 8)
    {
      if (3 > 0)
      {
        if (8 > 0)
        {
          n = n + A_2_7;
        }
        n = n + A_2_8;
        if (8 < 9)
        {
          n = n + A_2_9;
        }
      }
      if (8 > 0)
      {
        n = n + A_3_7;
      }
      if (8 < 9)
      {
        n = n + A_3_9;
      }
      if (3 < 9)
      {
        if (8 > 0)
        {
          n = n + A_4_7;
        }
        n = n + A_4_8;
        if (8 < 9)
        {
          n = n + A_4_9;
        }
      }
    } else if (x == 9)
    {
      if (3 > 0)
      {
        if (9 > 0)
        {
          n = n + A_2_8;
        }
        n = n + A_2_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
      if (9 > 0)
      {
        n = n + A_3_8;
      }
      if (9 < 9)
      {
        n = n + not_there;
      }
      if (3 < 9)
      {
        if (9 > 0)
        {
          n = n + A_4_8;
        }
        n = n + A_4_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
    }
  } else if (y == 4)
  {
    if (x == 0)
    {
      if (4 > 0)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_3_0;
        if (0 < 9)
        {
          n = n + A_3_1;
        }
      }
      if (0 > 0)
      {
        n = n + not_there;
      }
      if (0 < 9)
      {
        n = n + A_4_1;
      }
      if (4 < 9)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_5_0;
        if (0 < 9)
        {
          n = n + A_5_1;
        }
      }
    } else if (x == 1)
    {
      if (4 > 0)
      {
        if (1 > 0)
        {
          n = n + A_3_0;
        }
        n = n + A_3_1;
        if (1 < 9)
        {
          n = n + A_3_2;
        }
      }
      if (1 > 0)
      {
        n = n + A_4_0;
      }
      if (1 < 9)
      {
        n = n + A_4_2;
      }
      if (4 < 9)
      {
        if (1 > 0)
        {
          n = n + A_5_0;
        }
        n = n + A_5_1;
        if (1 < 9)
        {
          n = n + A_5_2;
        }
      }
    } else if (x == 2)
    {
      if (4 > 0)
      {
        if (2 > 0)
        {
          n = n + A_3_1;
        }
        n = n + A_3_2;
        if (2 < 9)
        {
          n = n + A_3_3;
        }
      }
      if (2 > 0)
      {
        n = n + A_4_1;
      }
      if (2 < 9)
      {
        n = n + A_4_3;
      }
      if (4 < 9)
      {
        if (2 > 0)
        {
          n = n + A_5_1;
        }
        n = n + A_5_2;
        if (2 < 9)
        {
          n = n + A_5_3;
        }
      }
    } else if (x == 3)
    {
      if (4 > 0)
      {
        if (3 > 0)
        {
          n = n + A_3_2;
        }
        n = n + A_3_3;
        if (3 < 9)
        {
          n = n + A_3_4;
        }
      }
      if (3 > 0)
      {
        n = n + A_4_2;
      }
      if (3 < 9)
      {
        n = n + A_4_4;
      }
      if (4 < 9)
      {
        if (3 > 0)
        {
          n = n + A_5_2;
        }
        n = n + A_5_3;
        if (3 < 9)
        {
          n = n + A_5_4;
        }
      }
    } else if (x == 4)
    {
      if (4 > 0)
      {
        if (4 > 0)
        {
          n = n + A_3_3;
        }
        n = n + A_3_4;
        if (4 < 9)
        {
          n = n + A_3_5;
        }
      }
      if (4 > 0)
      {
        n = n + A_4_3;
      }
      if (4 < 9)
      {
        n = n + A_4_5;
      }
      if (4 < 9)
      {
        if (4 > 0)
        {
          n = n + A_5_3;
        }
        n = n + A_5_4;
        if (4 < 9)
        {
          n = n + A_5_5;
        }
      }
    } else if (x == 5)
    {
      if (4 > 0)
      {
        if (5 > 0)
        {
          n = n + A_3_4;
        }
        n = n + A_3_5;
        if (5 < 9)
        {
          n = n + A_3_6;
        }
      }
      if (5 > 0)
      {
        n = n + A_4_4;
      }
      if (5 < 9)
      {
        n = n + A_4_6;
      }
      if (4 < 9)
      {
        if (5 > 0)
        {
          n = n + A_5_4;
        }
        n = n + A_5_5;
        if (5 < 9)
        {
          n = n + A_5_6;
        }
      }
    } else if (x == 6)
    {
      if (4 > 0)
      {
        if (6 > 0)
        {
          n = n + A_3_5;
        }
        n = n + A_3_6;
        if (6 < 9)
        {
          n = n + A_3_7;
        }
      }
      if (6 > 0)
      {
        n = n + A_4_5;
      }
      if (6 < 9)
      {
        n = n + A_4_7;
      }
      if (4 < 9)
      {
        if (6 > 0)
        {
          n = n + A_5_5;
        }
        n = n + A_5_6;
        if (6 < 9)
        {
          n = n + A_5_7;
        }
      }
    } else if (x == 7)
    {
      if (4 > 0)
      {
        if (7 > 0)
        {
          n = n + A_3_6;
        }
        n = n + A_3_7;
        if (7 < 9)
        {
          n = n + A_3_8;
        }
      }
      if (7 > 0)
      {
        n = n + A_4_6;
      }
      if (7 < 9)
      {
        n = n + A_4_8;
      }
      if (4 < 9)
      {
        if (7 > 0)
        {
          n = n + A_5_6;
        }
        n = n + A_5_7;
        if (7 < 9)
        {
          n = n + A_5_8;
        }
      }
    } else if (x == 8)
    {
      if (4 > 0)
      {
        if (8 > 0)
        {
          n = n + A_3_7;
        }
        n = n + A_3_8;
        if (8 < 9)
        {
          n = n + A_3_9;
        }
      }
      if (8 > 0)
      {
        n = n + A_4_7;
      }
      if (8 < 9)
      {
        n = n + A_4_9;
      }
      if (4 < 9)
      {
        if (8 > 0)
        {
          n = n + A_5_7;
        }
        n = n + A_5_8;
        if (8 < 9)
        {
          n = n + A_5_9;
        }
      }
    } else if (x == 9)
    {
      if (4 > 0)
      {
        if (9 > 0)
        {
          n = n + A_3_8;
        }
        n = n + A_3_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
      if (9 > 0)
      {
        n = n + A_4_8;
      }
      if (9 < 9)
      {
        n = n + not_there;
      }
      if (4 < 9)
      {
        if (9 > 0)
        {
          n = n + A_5_8;
        }
        n = n + A_5_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
    }
  } else if (y == 5)
  {
    if (x == 0)
    {
      if (5 > 0)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_4_0;
        if (0 < 9)
        {
          n = n + A_4_1;
        }
      }
      if (0 > 0)
      {
        n = n + not_there;
      }
      if (0 < 9)
      {
        n = n + A_5_1;
      }
      if (5 < 9)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_6_0;
        if (0 < 9)
        {
          n = n + A_6_1;
        }
      }
    } else if (x == 1)
    {
      if (5 > 0)
      {
        if (1 > 0)
        {
          n = n + A_4_0;
        }
        n = n + A_4_1;
        if (1 < 9)
        {
          n = n + A_4_2;
        }
      }
      if (1 > 0)
      {
        n = n + A_5_0;
      }
      if (1 < 9)
      {
        n = n + A_5_2;
      }
      if (5 < 9)
      {
        if (1 > 0)
        {
          n = n + A_6_0;
        }
        n = n + A_6_1;
        if (1 < 9)
        {
          n = n + A_6_2;
        }
      }
    } else if (x == 2)
    {
      if (5 > 0)
      {
        if (2 > 0)
        {
          n = n + A_4_1;
        }
        n = n + A_4_2;
        if (2 < 9)
        {
          n = n + A_4_3;
        }
      }
      if (2 > 0)
      {
        n = n + A_5_1;
      }
      if (2 < 9)
      {
        n = n + A_5_3;
      }
      if (5 < 9)
      {
        if (2 > 0)
        {
          n = n + A_6_1;
        }
        n = n + A_6_2;
        if (2 < 9)
        {
          n = n + A_6_3;
        }
      }
    } else if (x == 3)
    {
      if (5 > 0)
      {
        if (3 > 0)
        {
          n = n + A_4_2;
        }
        n = n + A_4_3;
        if (3 < 9)
        {
          n = n + A_4_4;
        }
      }
      if (3 > 0)
      {
        n = n + A_5_2;
      }
      if (3 < 9)
      {
        n = n + A_5_4;
      }
      if (5 < 9)
      {
        if (3 > 0)
        {
          n = n + A_6_2;
        }
        n = n + A_6_3;
        if (3 < 9)
        {
          n = n + A_6_4;
        }
      }
    } else if (x == 4)
    {
      if (5 > 0)
      {
        if (4 > 0)
        {
          n = n + A_4_3;
        }
        n = n + A_4_4;
        if (4 < 9)
        {
          n = n + A_4_5;
        }
      }
      if (4 > 0)
      {
        n = n + A_5_3;
      }
      if (4 < 9)
      {
        n = n + A_5_5;
      }
      if (5 < 9)
      {
        if (4 > 0)
        {
          n = n + A_6_3;
        }
        n = n + A_6_4;
        if (4 < 9)
        {
          n = n + A_6_5;
        }
      }
    } else if (x == 5)
    {
      if (5 > 0)
      {
        if (5 > 0)
        {
          n = n + A_4_4;
        }
        n = n + A_4_5;
        if (5 < 9)
        {
          n = n + A_4_6;
        }
      }
      if (5 > 0)
      {
        n = n + A_5_4;
      }
      if (5 < 9)
      {
        n = n + A_5_6;
      }
      if (5 < 9)
      {
        if (5 > 0)
        {
          n = n + A_6_4;
        }
        n = n + A_6_5;
        if (5 < 9)
        {
          n = n + A_6_6;
        }
      }
    } else if (x == 6)
    {
      if (5 > 0)
      {
        if (6 > 0)
        {
          n = n + A_4_5;
        }
        n = n + A_4_6;
        if (6 < 9)
        {
          n = n + A_4_7;
        }
      }
      if (6 > 0)
      {
        n = n + A_5_5;
      }
      if (6 < 9)
      {
        n = n + A_5_7;
      }
      if (5 < 9)
      {
        if (6 > 0)
        {
          n = n + A_6_5;
        }
        n = n + A_6_6;
        if (6 < 9)
        {
          n = n + A_6_7;
        }
      }
    } else if (x == 7)
    {
      if (5 > 0)
      {
        if (7 > 0)
        {
          n = n + A_4_6;
        }
        n = n + A_4_7;
        if (7 < 9)
        {
          n = n + A_4_8;
        }
      }
      if (7 > 0)
      {
        n = n + A_5_6;
      }
      if (7 < 9)
      {
        n = n + A_5_8;
      }
      if (5 < 9)
      {
        if (7 > 0)
        {
          n = n + A_6_6;
        }
        n = n + A_6_7;
        if (7 < 9)
        {
          n = n + A_6_8;
        }
      }
    } else if (x == 8)
    {
      if (5 > 0)
      {
        if (8 > 0)
        {
          n = n + A_4_7;
        }
        n = n + A_4_8;
        if (8 < 9)
        {
          n = n + A_4_9;
        }
      }
      if (8 > 0)
      {
        n = n + A_5_7;
      }
      if (8 < 9)
      {
        n = n + A_5_9;
      }
      if (5 < 9)
      {
        if (8 > 0)
        {
          n = n + A_6_7;
        }
        n = n + A_6_8;
        if (8 < 9)
        {
          n = n + A_6_9;
        }
      }
    } else if (x == 9)
    {
      if (5 > 0)
      {
        if (9 > 0)
        {
          n = n + A_4_8;
        }
        n = n + A_4_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
      if (9 > 0)
      {
        n = n + A_5_8;
      }
      if (9 < 9)
      {
        n = n + not_there;
      }
      if (5 < 9)
      {
        if (9 > 0)
        {
          n = n + A_6_8;
        }
        n = n + A_6_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
    }
  } else if (y == 6)
  {
    if (x == 0)
    {
      if (6 > 0)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_5_0;
        if (0 < 9)
        {
          n = n + A_5_1;
        }
      }
      if (0 > 0)
      {
        n = n + not_there;
      }
      if (0 < 9)
      {
        n = n + A_6_1;
      }
      if (6 < 9)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_7_0;
        if (0 < 9)
        {
          n = n + A_7_1;
        }
      }
    } else if (x == 1)
    {
      if (6 > 0)
      {
        if (1 > 0)
        {
          n = n + A_5_0;
        }
        n = n + A_5_1;
        if (1 < 9)
        {
          n = n + A_5_2;
        }
      }
      if (1 > 0)
      {
        n = n + A_6_0;
      }
      if (1 < 9)
      {
        n = n + A_6_2;
      }
      if (6 < 9)
      {
        if (1 > 0)
        {
          n = n + A_7_0;
        }
        n = n + A_7_1;
        if (1 < 9)
        {
          n = n + A_7_2;
        }
      }
    } else if (x == 2)
    {
      if (6 > 0)
      {
        if (2 > 0)
        {
          n = n + A_5_1;
        }
        n = n + A_5_2;
        if (2 < 9)
        {
          n = n + A_5_3;
        }
      }
      if (2 > 0)
      {
        n = n + A_6_1;
      }
      if (2 < 9)
      {
        n = n + A_6_3;
      }
      if (6 < 9)
      {
        if (2 > 0)
        {
          n = n + A_7_1;
        }
        n = n + A_7_2;
        if (2 < 9)
        {
          n = n + A_7_3;
        }
      }
    } else if (x == 3)
    {
      if (6 > 0)
      {
        if (3 > 0)
        {
          n = n + A_5_2;
        }
        n = n + A_5_3;
        if (3 < 9)
        {
          n = n + A_5_4;
        }
      }
      if (3 > 0)
      {
        n = n + A_6_2;
      }
      if (3 < 9)
      {
        n = n + A_6_4;
      }
      if (6 < 9)
      {
        if (3 > 0)
        {
          n = n + A_7_2;
        }
        n = n + A_7_3;
        if (3 < 9)
        {
          n = n + A_7_4;
        }
      }
    } else if (x == 4)
    {
      if (6 > 0)
      {
        if (4 > 0)
        {
          n = n + A_5_3;
        }
        n = n + A_5_4;
        if (4 < 9)
        {
          n = n + A_5_5;
        }
      }
      if (4 > 0)
      {
        n = n + A_6_3;
      }
      if (4 < 9)
      {
        n = n + A_6_5;
      }
      if (6 < 9)
      {
        if (4 > 0)
        {
          n = n + A_7_3;
        }
        n = n + A_7_4;
        if (4 < 9)
        {
          n = n + A_7_5;
        }
      }
    } else if (x == 5)
    {
      if (6 > 0)
      {
        if (5 > 0)
        {
          n = n + A_5_4;
        }
        n = n + A_5_5;
        if (5 < 9)
        {
          n = n + A_5_6;
        }
      }
      if (5 > 0)
      {
        n = n + A_6_4;
      }
      if (5 < 9)
      {
        n = n + A_6_6;
      }
      if (6 < 9)
      {
        if (5 > 0)
        {
          n = n + A_7_4;
        }
        n = n + A_7_5;
        if (5 < 9)
        {
          n = n + A_7_6;
        }
      }
    } else if (x == 6)
    {
      if (6 > 0)
      {
        if (6 > 0)
        {
          n = n + A_5_5;
        }
        n = n + A_5_6;
        if (6 < 9)
        {
          n = n + A_5_7;
        }
      }
      if (6 > 0)
      {
        n = n + A_6_5;
      }
      if (6 < 9)
      {
        n = n + A_6_7;
      }
      if (6 < 9)
      {
        if (6 > 0)
        {
          n = n + A_7_5;
        }
        n = n + A_7_6;
        if (6 < 9)
        {
          n = n + A_7_7;
        }
      }
    } else if (x == 7)
    {
      if (6 > 0)
      {
        if (7 > 0)
        {
          n = n + A_5_6;
        }
        n = n + A_5_7;
        if (7 < 9)
        {
          n = n + A_5_8;
        }
      }
      if (7 > 0)
      {
        n = n + A_6_6;
      }
      if (7 < 9)
      {
        n = n + A_6_8;
      }
      if (6 < 9)
      {
        if (7 > 0)
        {
          n = n + A_7_6;
        }
        n = n + A_7_7;
        if (7 < 9)
        {
          n = n + A_7_8;
        }
      }
    } else if (x == 8)
    {
      if (6 > 0)
      {
        if (8 > 0)
        {
          n = n + A_5_7;
        }
        n = n + A_5_8;
        if (8 < 9)
        {
          n = n + A_5_9;
        }
      }
      if (8 > 0)
      {
        n = n + A_6_7;
      }
      if (8 < 9)
      {
        n = n + A_6_9;
      }
      if (6 < 9)
      {
        if (8 > 0)
        {
          n = n + A_7_7;
        }
        n = n + A_7_8;
        if (8 < 9)
        {
          n = n + A_7_9;
        }
      }
    } else if (x == 9)
    {
      if (6 > 0)
      {
        if (9 > 0)
        {
          n = n + A_5_8;
        }
        n = n + A_5_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
      if (9 > 0)
      {
        n = n + A_6_8;
      }
      if (9 < 9)
      {
        n = n + not_there;
      }
      if (6 < 9)
      {
        if (9 > 0)
        {
          n = n + A_7_8;
        }
        n = n + A_7_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
    }
  } else if (y == 7)
  {
    if (x == 0)
    {
      if (7 > 0)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_6_0;
        if (0 < 9)
        {
          n = n + A_6_1;
        }
      }
      if (0 > 0)
      {
        n = n + not_there;
      }
      if (0 < 9)
      {
        n = n + A_7_1;
      }
      if (7 < 9)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_8_0;
        if (0 < 9)
        {
          n = n + A_8_1;
        }
      }
    } else if (x == 1)
    {
      if (7 > 0)
      {
        if (1 > 0)
        {
          n = n + A_6_0;
        }
        n = n + A_6_1;
        if (1 < 9)
        {
          n = n + A_6_2;
        }
      }
      if (1 > 0)
      {
        n = n + A_7_0;
      }
      if (1 < 9)
      {
        n = n + A_7_2;
      }
      if (7 < 9)
      {
        if (1 > 0)
        {
          n = n + A_8_0;
        }
        n = n + A_8_1;
        if (1 < 9)
        {
          n = n + A_8_2;
        }
      }
    } else if (x == 2)
    {
      if (7 > 0)
      {
        if (2 > 0)
        {
          n = n + A_6_1;
        }
        n = n + A_6_2;
        if (2 < 9)
        {
          n = n + A_6_3;
        }
      }
      if (2 > 0)
      {
        n = n + A_7_1;
      }
      if (2 < 9)
      {
        n = n + A_7_3;
      }
      if (7 < 9)
      {
        if (2 > 0)
        {
          n = n + A_8_1;
        }
        n = n + A_8_2;
        if (2 < 9)
        {
          n = n + A_8_3;
        }
      }
    } else if (x == 3)
    {
      if (7 > 0)
      {
        if (3 > 0)
        {
          n = n + A_6_2;
        }
        n = n + A_6_3;
        if (3 < 9)
        {
          n = n + A_6_4;
        }
      }
      if (3 > 0)
      {
        n = n + A_7_2;
      }
      if (3 < 9)
      {
        n = n + A_7_4;
      }
      if (7 < 9)
      {
        if (3 > 0)
        {
          n = n + A_8_2;
        }
        n = n + A_8_3;
        if (3 < 9)
        {
          n = n + A_8_4;
        }
      }
    } else if (x == 4)
    {
      if (7 > 0)
      {
        if (4 > 0)
        {
          n = n + A_6_3;
        }
        n = n + A_6_4;
        if (4 < 9)
        {
          n = n + A_6_5;
        }
      }
      if (4 > 0)
      {
        n = n + A_7_3;
      }
      if (4 < 9)
      {
        n = n + A_7_5;
      }
      if (7 < 9)
      {
        if (4 > 0)
        {
          n = n + A_8_3;
        }
        n = n + A_8_4;
        if (4 < 9)
        {
          n = n + A_8_5;
        }
      }
    } else if (x == 5)
    {
      if (7 > 0)
      {
        if (5 > 0)
        {
          n = n + A_6_4;
        }
        n = n + A_6_5;
        if (5 < 9)
        {
          n = n + A_6_6;
        }
      }
      if (5 > 0)
      {
        n = n + A_7_4;
      }
      if (5 < 9)
      {
        n = n + A_7_6;
      }
      if (7 < 9)
      {
        if (5 > 0)
        {
          n = n + A_8_4;
        }
        n = n + A_8_5;
        if (5 < 9)
        {
          n = n + A_8_6;
        }
      }
    } else if (x == 6)
    {
      if (7 > 0)
      {
        if (6 > 0)
        {
          n = n + A_6_5;
        }
        n = n + A_6_6;
        if (6 < 9)
        {
          n = n + A_6_7;
        }
      }
      if (6 > 0)
      {
        n = n + A_7_5;
      }
      if (6 < 9)
      {
        n = n + A_7_7;
      }
      if (7 < 9)
      {
        if (6 > 0)
        {
          n = n + A_8_5;
        }
        n = n + A_8_6;
        if (6 < 9)
        {
          n = n + A_8_7;
        }
      }
    } else if (x == 7)
    {
      if (7 > 0)
      {
        if (7 > 0)
        {
          n = n + A_6_6;
        }
        n = n + A_6_7;
        if (7 < 9)
        {
          n = n + A_6_8;
        }
      }
      if (7 > 0)
      {
        n = n + A_7_6;
      }
      if (7 < 9)
      {
        n = n + A_7_8;
      }
      if (7 < 9)
      {
        if (7 > 0)
        {
          n = n + A_8_6;
        }
        n = n + A_8_7;
        if (7 < 9)
        {
          n = n + A_8_8;
        }
      }
    } else if (x == 8)
    {
      if (7 > 0)
      {
        if (8 > 0)
        {
          n = n + A_6_7;
        }
        n = n + A_6_8;
        if (8 < 9)
        {
          n = n + A_6_9;
        }
      }
      if (8 > 0)
      {
        n = n + A_7_7;
      }
      if (8 < 9)
      {
        n = n + A_7_9;
      }
      if (7 < 9)
      {
        if (8 > 0)
        {
          n = n + A_8_7;
        }
        n = n + A_8_8;
        if (8 < 9)
        {
          n = n + A_8_9;
        }
      }
    } else if (x == 9)
    {
      if (7 > 0)
      {
        if (9 > 0)
        {
          n = n + A_6_8;
        }
        n = n + A_6_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
      if (9 > 0)
      {
        n = n + A_7_8;
      }
      if (9 < 9)
      {
        n = n + not_there;
      }
      if (7 < 9)
      {
        if (9 > 0)
        {
          n = n + A_8_8;
        }
        n = n + A_8_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
    }
  } else if (y == 8)
  {
    if (x == 0)
    {
      if (8 > 0)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_7_0;
        if (0 < 9)
        {
          n = n + A_7_1;
        }
      }
      if (0 > 0)
      {
        n = n + not_there;
      }
      if (0 < 9)
      {
        n = n + A_8_1;
      }
      if (8 < 9)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_9_0;
        if (0 < 9)
        {
          n = n + A_9_1;
        }
      }
    } else if (x == 1)
    {
      if (8 > 0)
      {
        if (1 > 0)
        {
          n = n + A_7_0;
        }
        n = n + A_7_1;
        if (1 < 9)
        {
          n = n + A_7_2;
        }
      }
      if (1 > 0)
      {
        n = n + A_8_0;
      }
      if (1 < 9)
      {
        n = n + A_8_2;
      }
      if (8 < 9)
      {
        if (1 > 0)
        {
          n = n + A_9_0;
        }
        n = n + A_9_1;
        if (1 < 9)
        {
          n = n + A_9_2;
        }
      }
    } else if (x == 2)
    {
      if (8 > 0)
      {
        if (2 > 0)
        {
          n = n + A_7_1;
        }
        n = n + A_7_2;
        if (2 < 9)
        {
          n = n + A_7_3;
        }
      }
      if (2 > 0)
      {
        n = n + A_8_1;
      }
      if (2 < 9)
      {
        n = n + A_8_3;
      }
      if (8 < 9)
      {
        if (2 > 0)
        {
          n = n + A_9_1;
        }
        n = n + A_9_2;
        if (2 < 9)
        {
          n = n + A_9_3;
        }
      }
    } else if (x == 3)
    {
      if (8 > 0)
      {
        if (3 > 0)
        {
          n = n + A_7_2;
        }
        n = n + A_7_3;
        if (3 < 9)
        {
          n = n + A_7_4;
        }
      }
      if (3 > 0)
      {
        n = n + A_8_2;
      }
      if (3 < 9)
      {
        n = n + A_8_4;
      }
      if (8 < 9)
      {
        if (3 > 0)
        {
          n = n + A_9_2;
        }
        n = n + A_9_3;
        if (3 < 9)
        {
          n = n + A_9_4;
        }
      }
    } else if (x == 4)
    {
      if (8 > 0)
      {
        if (4 > 0)
        {
          n = n + A_7_3;
        }
        n = n + A_7_4;
        if (4 < 9)
        {
          n = n + A_7_5;
        }
      }
      if (4 > 0)
      {
        n = n + A_8_3;
      }
      if (4 < 9)
      {
        n = n + A_8_5;
      }
      if (8 < 9)
      {
        if (4 > 0)
        {
          n = n + A_9_3;
        }
        n = n + A_9_4;
        if (4 < 9)
        {
          n = n + A_9_5;
        }
      }
    } else if (x == 5)
    {
      if (8 > 0)
      {
        if (5 > 0)
        {
          n = n + A_7_4;
        }
        n = n + A_7_5;
        if (5 < 9)
        {
          n = n + A_7_6;
        }
      }
      if (5 > 0)
      {
        n = n + A_8_4;
      }
      if (5 < 9)
      {
        n = n + A_8_6;
      }
      if (8 < 9)
      {
        if (5 > 0)
        {
          n = n + A_9_4;
        }
        n = n + A_9_5;
        if (5 < 9)
        {
          n = n + A_9_6;
        }
      }
    } else if (x == 6)
    {
      if (8 > 0)
      {
        if (6 > 0)
        {
          n = n + A_7_5;
        }
        n = n + A_7_6;
        if (6 < 9)
        {
          n = n + A_7_7;
        }
      }
      if (6 > 0)
      {
        n = n + A_8_5;
      }
      if (6 < 9)
      {
        n = n + A_8_7;
      }
      if (8 < 9)
      {
        if (6 > 0)
        {
          n = n + A_9_5;
        }
        n = n + A_9_6;
        if (6 < 9)
        {
          n = n + A_9_7;
        }
      }
    } else if (x == 7)
    {
      if (8 > 0)
      {
        if (7 > 0)
        {
          n = n + A_7_6;
        }
        n = n + A_7_7;
        if (7 < 9)
        {
          n = n + A_7_8;
        }
      }
      if (7 > 0)
      {
        n = n + A_8_6;
      }
      if (7 < 9)
      {
        n = n + A_8_8;
      }
      if (8 < 9)
      {
        if (7 > 0)
        {
          n = n + A_9_6;
        }
        n = n + A_9_7;
        if (7 < 9)
        {
          n = n + A_9_8;
        }
      }
    } else if (x == 8)
    {
      if (8 > 0)
      {
        if (8 > 0)
        {
          n = n + A_7_7;
        }
        n = n + A_7_8;
        if (8 < 9)
        {
          n = n + A_7_9;
        }
      }
      if (8 > 0)
      {
        n = n + A_8_7;
      }
      if (8 < 9)
      {
        n = n + A_8_9;
      }
      if (8 < 9)
      {
        if (8 > 0)
        {
          n = n + A_9_7;
        }
        n = n + A_9_8;
        if (8 < 9)
        {
          n = n + A_9_9;
        }
      }
    } else if (x == 9)
    {
      if (8 > 0)
      {
        if (9 > 0)
        {
          n = n + A_7_8;
        }
        n = n + A_7_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
      if (9 > 0)
      {
        n = n + A_8_8;
      }
      if (9 < 9)
      {
        n = n + not_there;
      }
      if (8 < 9)
      {
        if (9 > 0)
        {
          n = n + A_9_8;
        }
        n = n + A_9_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
    }
  } else if (y == 9)
  {
    if (x == 0)
    {
      if (9 > 0)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + A_8_0;
        if (0 < 9)
        {
          n = n + A_8_1;
        }
      }
      if (0 > 0)
      {
        n = n + not_there;
      }
      if (0 < 9)
      {
        n = n + A_9_1;
      }
      if (9 < 9)
      {
        if (0 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (0 < 9)
        {
          n = n + not_there;
        }
      }
    } else if (x == 1)
    {
      if (9 > 0)
      {
        if (1 > 0)
        {
          n = n + A_8_0;
        }
        n = n + A_8_1;
        if (1 < 9)
        {
          n = n + A_8_2;
        }
      }
      if (1 > 0)
      {
        n = n + A_9_0;
      }
      if (1 < 9)
      {
        n = n + A_9_2;
      }
      if (9 < 9)
      {
        if (1 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (1 < 9)
        {
          n = n + not_there;
        }
      }
    } else if (x == 2)
    {
      if (9 > 0)
      {
        if (2 > 0)
        {
          n = n + A_8_1;
        }
        n = n + A_8_2;
        if (2 < 9)
        {
          n = n + A_8_3;
        }
      }
      if (2 > 0)
      {
        n = n + A_9_1;
      }
      if (2 < 9)
      {
        n = n + A_9_3;
      }
      if (9 < 9)
      {
        if (2 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (2 < 9)
        {
          n = n + not_there;
        }
      }
    } else if (x == 3)
    {
      if (9 > 0)
      {
        if (3 > 0)
        {
          n = n + A_8_2;
        }
        n = n + A_8_3;
        if (3 < 9)
        {
          n = n + A_8_4;
        }
      }
      if (3 > 0)
      {
        n = n + A_9_2;
      }
      if (3 < 9)
      {
        n = n + A_9_4;
      }
      if (9 < 9)
      {
        if (3 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (3 < 9)
        {
          n = n + not_there;
        }
      }
    } else if (x == 4)
    {
      if (9 > 0)
      {
        if (4 > 0)
        {
          n = n + A_8_3;
        }
        n = n + A_8_4;
        if (4 < 9)
        {
          n = n + A_8_5;
        }
      }
      if (4 > 0)
      {
        n = n + A_9_3;
      }
      if (4 < 9)
      {
        n = n + A_9_5;
      }
      if (9 < 9)
      {
        if (4 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (4 < 9)
        {
          n = n + not_there;
        }
      }
    } else if (x == 5)
    {
      if (9 > 0)
      {
        if (5 > 0)
        {
          n = n + A_8_4;
        }
        n = n + A_8_5;
        if (5 < 9)
        {
          n = n + A_8_6;
        }
      }
      if (5 > 0)
      {
        n = n + A_9_4;
      }
      if (5 < 9)
      {
        n = n + A_9_6;
      }
      if (9 < 9)
      {
        if (5 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (5 < 9)
        {
          n = n + not_there;
        }
      }
    } else if (x == 6)
    {
      if (9 > 0)
      {
        if (6 > 0)
        {
          n = n + A_8_5;
        }
        n = n + A_8_6;
        if (6 < 9)
        {
          n = n + A_8_7;
        }
      }
      if (6 > 0)
      {
        n = n + A_9_5;
      }
      if (6 < 9)
      {
        n = n + A_9_7;
      }
      if (9 < 9)
      {
        if (6 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (6 < 9)
        {
          n = n + not_there;
        }
      }
    } else if (x == 7)
    {
      if (9 > 0)
      {
        if (7 > 0)
        {
          n = n + A_8_6;
        }
        n = n + A_8_7;
        if (7 < 9)
        {
          n = n + A_8_8;
        }
      }
      if (7 > 0)
      {
        n = n + A_9_6;
      }
      if (7 < 9)
      {
        n = n + A_9_8;
      }
      if (9 < 9)
      {
        if (7 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (7 < 9)
        {
          n = n + not_there;
        }
      }
    } else if (x == 8)
    {
      if (9 > 0)
      {
        if (8 > 0)
        {
          n = n + A_8_7;
        }
        n = n + A_8_8;
        if (8 < 9)
        {
          n = n + A_8_9;
        }
      }
      if (8 > 0)
      {
        n = n + A_9_7;
      }
      if (8 < 9)
      {
        n = n + A_9_9;
      }
      if (9 < 9)
      {
        if (8 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (8 < 9)
        {
          n = n + not_there;
        }
      }
    } else if (x == 9)
    {
      if (9 > 0)
      {
        if (9 > 0)
        {
          n = n + A_8_8;
        }
        n = n + A_8_9;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
      if (9 > 0)
      {
        n = n + A_9_8;
      }
      if (9 < 9)
      {
        n = n + not_there;
      }
      if (9 < 9)
      {
        if (9 > 0)
        {
          n = n + not_there;
        }
        n = n + not_there;
        if (9 < 9)
        {
          n = n + not_there;
        }
      }
    }
  }
  return n;
}
void printboard(int gen)
{
  int i;
  int j;
  prints("Generation ");
  printi(gen);
  prints(":\n");
  i = 0;
  while (i <= 9)
  {
    if (i == 0)
    {
      j = 0;
      while (j <= 9)
      {
        if (j == 0)
        {
          printi(A_0_0);
          prints(" ");
        } else if (j == 1)
        {
          printi(A_0_1);
          prints(" ");
        } else if (j == 2)
        {
          printi(A_0_2);
          prints(" ");
        } else if (j == 3)
        {
          printi(A_0_3);
          prints(" ");
        } else if (j == 4)
        {
          printi(A_0_4);
          prints(" ");
        } else if (j == 5)
        {
          printi(A_0_5);
          prints(" ");
        } else if (j == 6)
        {
          printi(A_0_6);
          prints(" ");
        } else if (j == 7)
        {
          printi(A_0_7);
          prints(" ");
        } else if (j == 8)
        {
          printi(A_0_8);
          prints(" ");
        } else if (j == 9)
        {
          printi(A_0_9);
          prints(" ");
        }
        j = j + 1;
      }
    } else if (i == 1)
    {
      j = 0;
      while (j <= 9)
      {
        if (j == 0)
        {
          printi(A_1_0);
          prints(" ");
        } else if (j == 1)
        {
          printi(A_1_1);
          prints(" ");
        } else if (j == 2)
        {
          printi(A_1_2);
          prints(" ");
        } else if (j == 3)
        {
          printi(A_1_3);
          prints(" ");
        } else if (j == 4)
        {
          printi(A_1_4);
          prints(" ");
        } else if (j == 5)
        {
          printi(A_1_5);
          prints(" ");
        } else if (j == 6)
        {
          printi(A_1_6);
          prints(" ");
        } else if (j == 7)
        {
          printi(A_1_7);
          prints(" ");
        } else if (j == 8)
        {
          printi(A_1_8);
          prints(" ");
        } else if (j == 9)
        {
          printi(A_1_9);
          prints(" ");
        }
        j = j + 1;
      }
    } else if (i == 2)
    {
      j = 0;
      while (j <= 9)
      {
        if (j == 0)
        {
          printi(A_2_0);
          prints(" ");
        } else if (j == 1)
        {
          printi(A_2_1);
          prints(" ");
        } else if (j == 2)
        {
          printi(A_2_2);
          prints(" ");
        } else if (j == 3)
        {
          printi(A_2_3);
          prints(" ");
        } else if (j == 4)
        {
          printi(A_2_4);
          prints(" ");
        } else if (j == 5)
        {
          printi(A_2_5);
          prints(" ");
        } else if (j == 6)
        {
          printi(A_2_6);
          prints(" ");
        } else if (j == 7)
        {
          printi(A_2_7);
          prints(" ");
        } else if (j == 8)
        {
          printi(A_2_8);
          prints(" ");
        } else if (j == 9)
        {
          printi(A_2_9);
          prints(" ");
        }
        j = j + 1;
      }
    } else if (i == 3)
    {
      j = 0;
      while (j <= 9)
      {
        if (j == 0)
        {
          printi(A_3_0);
          prints(" ");
        } else if (j == 1)
        {
          printi(A_3_1);
          prints(" ");
        } else if (j == 2)
        {
          printi(A_3_2);
          prints(" ");
        } else if (j == 3)
        {
          printi(A_3_3);
          prints(" ");
        } else if (j == 4)
        {
          printi(A_3_4);
          prints(" ");
        } else if (j == 5)
        {
          printi(A_3_5);
          prints(" ");
        } else if (j == 6)
        {
          printi(A_3_6);
          prints(" ");
        } else if (j == 7)
        {
          printi(A_3_7);
          prints(" ");
        } else if (j == 8)
        {
          printi(A_3_8);
          prints(" ");
        } else if (j == 9)
        {
          printi(A_3_9);
          prints(" ");
        }
        j = j + 1;
      }
    } else if (i == 4)
    {
      j = 0;
      while (j <= 9)
      {
        if (j == 0)
        {
          printi(A_4_0);
          prints(" ");
        } else if (j == 1)
        {
          printi(A_4_1);
          prints(" ");
        } else if (j == 2)
        {
          printi(A_4_2);
          prints(" ");
        } else if (j == 3)
        {
          printi(A_4_3);
          prints(" ");
        } else if (j == 4)
        {
          printi(A_4_4);
          prints(" ");
        } else if (j == 5)
        {
          printi(A_4_5);
          prints(" ");
        } else if (j == 6)
        {
          printi(A_4_6);
          prints(" ");
        } else if (j == 7)
        {
          printi(A_4_7);
          prints(" ");
        } else if (j == 8)
        {
          printi(A_4_8);
          prints(" ");
        } else if (j == 9)
        {
          printi(A_4_9);
          prints(" ");
        }
        j = j + 1;
      }
    } else if (i == 5)
    {
      j = 0;
      while (j <= 9)
      {
        if (j == 0)
        {
          printi(A_5_0);
          prints(" ");
        } else if (j == 1)
        {
          printi(A_5_1);
          prints(" ");
        } else if (j == 2)
        {
          printi(A_5_2);
          prints(" ");
        } else if (j == 3)
        {
          printi(A_5_3);
          prints(" ");
        } else if (j == 4)
        {
          printi(A_5_4);
          prints(" ");
        } else if (j == 5)
        {
          printi(A_5_5);
          prints(" ");
        } else if (j == 6)
        {
          printi(A_5_6);
          prints(" ");
        } else if (j == 7)
        {
          printi(A_5_7);
          prints(" ");
        } else if (j == 8)
        {
          printi(A_5_8);
          prints(" ");
        } else if (j == 9)
        {
          printi(A_5_9);
          prints(" ");
        }
        j = j + 1;
      }
    } else if (i == 6)
    {
      j = 0;
      while (j <= 9)
      {
        if (j == 0)
        {
          printi(A_6_0);
          prints(" ");
        } else if (j == 1)
        {
          printi(A_6_1);
          prints(" ");
        } else if (j == 2)
        {
          printi(A_6_2);
          prints(" ");
        } else if (j == 3)
        {
          printi(A_6_3);
          prints(" ");
        } else if (j == 4)
        {
          printi(A_6_4);
          prints(" ");
        } else if (j == 5)
        {
          printi(A_6_5);
          prints(" ");
        } else if (j == 6)
        {
          printi(A_6_6);
          prints(" ");
        } else if (j == 7)
        {
          printi(A_6_7);
          prints(" ");
        } else if (j == 8)
        {
          printi(A_6_8);
          prints(" ");
        } else if (j == 9)
        {
          printi(A_6_9);
          prints(" ");
        }
        j = j + 1;
      }
    } else if (i == 7)
    {
      j = 0;
      while (j <= 9)
      {
        if (j == 0)
        {
          printi(A_7_0);
          prints(" ");
        } else if (j == 1)
        {
          printi(A_7_1);
          prints(" ");
        } else if (j == 2)
        {
          printi(A_7_2);
          prints(" ");
        } else if (j == 3)
        {
          printi(A_7_3);
          prints(" ");
        } else if (j == 4)
        {
          printi(A_7_4);
          prints(" ");
        } else if (j == 5)
        {
          printi(A_7_5);
          prints(" ");
        } else if (j == 6)
        {
          printi(A_7_6);
          prints(" ");
        } else if (j == 7)
        {
          printi(A_7_7);
          prints(" ");
        } else if (j == 8)
        {
          printi(A_7_8);
          prints(" ");
        } else if (j == 9)
        {
          printi(A_7_9);
          prints(" ");
        }
        j = j + 1;
      }
    } else if (i == 8)
    {
      j = 0;
      while (j <= 9)
      {
        if (j == 0)
        {
          printi(A_8_0);
          prints(" ");
        } else if (j == 1)
        {
          printi(A_8_1);
          prints(" ");
        } else if (j == 2)
        {
          printi(A_8_2);
          prints(" ");
        } else if (j == 3)
        {
          printi(A_8_3);
          prints(" ");
        } else if (j == 4)
        {
          printi(A_8_4);
          prints(" ");
        } else if (j == 5)
        {
          printi(A_8_5);
          prints(" ");
        } else if (j == 6)
        {
          printi(A_8_6);
          prints(" ");
        } else if (j == 7)
        {
          printi(A_8_7);
          prints(" ");
        } else if (j == 8)
        {
          printi(A_8_8);
          prints(" ");
        } else if (j == 9)
        {
          printi(A_8_9);
          prints(" ");
        }
        j = j + 1;
      }
    } else if (i == 9)
    {
      j = 0;
      while (j <= 9)
      {
        if (j == 0)
        {
          printi(A_9_0);
          prints(" ");
        } else if (j == 1)
        {
          printi(A_9_1);
          prints(" ");
        } else if (j == 2)
        {
          printi(A_9_2);
          prints(" ");
        } else if (j == 3)
        {
          printi(A_9_3);
          prints(" ");
        } else if (j == 4)
        {
          printi(A_9_4);
          prints(" ");
        } else if (j == 5)
        {
          printi(A_9_5);
          prints(" ");
        } else if (j == 6)
        {
          printi(A_9_6);
          prints(" ");
        } else if (j == 7)
        {
          printi(A_9_7);
          prints(" ");
        } else if (j == 8)
        {
          printi(A_9_8);
          prints(" ");
        } else if (j == 9)
        {
          printi(A_9_9);
          prints(" ");
        }
        j = j + 1;
      }
    }
    prints("\n");
    i = i + 1;
  }
}
int morerandom()
{
  return INTERNALrandom() % 57;
  INTERNALrandom();
}

int INTERNALX;

void INTERNALseed(int seed)
{
  INTERNALX = seed;
}

//
//  Linear congruential method of generating pseudorandom
//  numbers, from Knuth's _The Art of Computer Programming, Volume 2:
//  Seminumerical Algorithms_, 3rd edition, Addison-Wesley, 1998.
//  Constants are chosen using Theorem A on page 17.
//
//  XXX - the period is long, but the lsb isn't random!
//
int INTERNALrandom()
{
  INTERNALX = (17 * INTERNALX + 13) % 32768;
  return INTERNALX;
}
