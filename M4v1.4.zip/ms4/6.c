// Global variable declaration

int g;
int h;

int ff() {
  return 1;
}

int func(int a, int b, int c, int d) {
  return a+b+c+d;
}

main() {
  h = func(2,3+4,g,ff());
  g = 5;
  printi(h);
  printi(g);
}
