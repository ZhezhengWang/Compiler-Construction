// Global variable declaration
boolean bb;
main() {
  int g;
  g = 1;
  bb = true;
  
  if (false) 
    printi(g);
  printi(2);
  if (bb) { 
    g = 3;
    printi(g);
  }
  printi(4);
}
