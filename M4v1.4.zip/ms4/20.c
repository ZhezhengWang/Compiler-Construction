int A_0;
int A_1;
int A_2;
int A_3;
int A_4;
int A_5;
int A_6;
int A_7;
int A_8;
int A_9;
int A_10;
int A_11;
int A_12;
int A_13;
int A_14;
int not_there;
main()
{
int i;
int j;
int t;
int min;
INTERNALseed(1);
i = 0;
while (i <= 14) {
if (i == 0) {
A_0 = INTERNALrandom() % 100;
}
else if (i == 1) {
A_1 = INTERNALrandom() % 100;
}
else if (i == 2) {
A_2 = INTERNALrandom() % 100;
}
else if (i == 3) {
A_3 = INTERNALrandom() % 100;
}
else if (i == 4) {
A_4 = INTERNALrandom() % 100;
}
else if (i == 5) {
A_5 = INTERNALrandom() % 100;
}
else if (i == 6) {
A_6 = INTERNALrandom() % 100;
}
else if (i == 7) {
A_7 = INTERNALrandom() % 100;
}
else if (i == 8) {
A_8 = INTERNALrandom() % 100;
}
else if (i == 9) {
A_9 = INTERNALrandom() % 100;
}
else if (i == 10) {
A_10 = INTERNALrandom() % 100;
}
else if (i == 11) {
A_11 = INTERNALrandom() % 100;
}
else if (i == 12) {
A_12 = INTERNALrandom() % 100;
}
else if (i == 13) {
A_13 = INTERNALrandom() % 100;
}
else if (i == 14) {
A_14 = INTERNALrandom() % 100;
}
i = i + 1;
}
printarray();
i = 0;
while (i <= 13) {
min = i;
j = i + 1;
while (j <= 14) {
if (j == 1) {
if (min == 0) {
if (A_1 < A_0) {
min = 1;
}
}
else if (min == 1) {
if (A_1 < A_1) {
min = 1;
}
}
else if (min == 2) {
if (A_1 < A_2) {
min = 1;
}
}
else if (min == 3) {
if (A_1 < A_3) {
min = 1;
}
}
else if (min == 4) {
if (A_1 < A_4) {
min = 1;
}
}
else if (min == 5) {
if (A_1 < A_5) {
min = 1;
}
}
else if (min == 6) {
if (A_1 < A_6) {
min = 1;
}
}
else if (min == 7) {
if (A_1 < A_7) {
min = 1;
}
}
else if (min == 8) {
if (A_1 < A_8) {
min = 1;
}
}
else if (min == 9) {
if (A_1 < A_9) {
min = 1;
}
}
else if (min == 10) {
if (A_1 < A_10) {
min = 1;
}
}
else if (min == 11) {
if (A_1 < A_11) {
min = 1;
}
}
else if (min == 12) {
if (A_1 < A_12) {
min = 1;
}
}
else if (min == 13) {
if (A_1 < A_13) {
min = 1;
}
}
else if (min == 14) {
if (A_1 < A_14) {
min = 1;
}
}
}
else if (j == 2) {
if (min == 0) {
if (A_2 < A_0) {
min = 2;
}
}
else if (min == 1) {
if (A_2 < A_1) {
min = 2;
}
}
else if (min == 2) {
if (A_2 < A_2) {
min = 2;
}
}
else if (min == 3) {
if (A_2 < A_3) {
min = 2;
}
}
else if (min == 4) {
if (A_2 < A_4) {
min = 2;
}
}
else if (min == 5) {
if (A_2 < A_5) {
min = 2;
}
}
else if (min == 6) {
if (A_2 < A_6) {
min = 2;
}
}
else if (min == 7) {
if (A_2 < A_7) {
min = 2;
}
}
else if (min == 8) {
if (A_2 < A_8) {
min = 2;
}
}
else if (min == 9) {
if (A_2 < A_9) {
min = 2;
}
}
else if (min == 10) {
if (A_2 < A_10) {
min = 2;
}
}
else if (min == 11) {
if (A_2 < A_11) {
min = 2;
}
}
else if (min == 12) {
if (A_2 < A_12) {
min = 2;
}
}
else if (min == 13) {
if (A_2 < A_13) {
min = 2;
}
}
else if (min == 14) {
if (A_2 < A_14) {
min = 2;
}
}
}
else if (j == 3) {
if (min == 0) {
if (A_3 < A_0) {
min = 3;
}
}
else if (min == 1) {
if (A_3 < A_1) {
min = 3;
}
}
else if (min == 2) {
if (A_3 < A_2) {
min = 3;
}
}
else if (min == 3) {
if (A_3 < A_3) {
min = 3;
}
}
else if (min == 4) {
if (A_3 < A_4) {
min = 3;
}
}
else if (min == 5) {
if (A_3 < A_5) {
min = 3;
}
}
else if (min == 6) {
if (A_3 < A_6) {
min = 3;
}
}
else if (min == 7) {
if (A_3 < A_7) {
min = 3;
}
}
else if (min == 8) {
if (A_3 < A_8) {
min = 3;
}
}
else if (min == 9) {
if (A_3 < A_9) {
min = 3;
}
}
else if (min == 10) {
if (A_3 < A_10) {
min = 3;
}
}
else if (min == 11) {
if (A_3 < A_11) {
min = 3;
}
}
else if (min == 12) {
if (A_3 < A_12) {
min = 3;
}
}
else if (min == 13) {
if (A_3 < A_13) {
min = 3;
}
}
else if (min == 14) {
if (A_3 < A_14) {
min = 3;
}
}
}
else if (j == 4) {
if (min == 0) {
if (A_4 < A_0) {
min = 4;
}
}
else if (min == 1) {
if (A_4 < A_1) {
min = 4;
}
}
else if (min == 2) {
if (A_4 < A_2) {
min = 4;
}
}
else if (min == 3) {
if (A_4 < A_3) {
min = 4;
}
}
else if (min == 4) {
if (A_4 < A_4) {
min = 4;
}
}
else if (min == 5) {
if (A_4 < A_5) {
min = 4;
}
}
else if (min == 6) {
if (A_4 < A_6) {
min = 4;
}
}
else if (min == 7) {
if (A_4 < A_7) {
min = 4;
}
}
else if (min == 8) {
if (A_4 < A_8) {
min = 4;
}
}
else if (min == 9) {
if (A_4 < A_9) {
min = 4;
}
}
else if (min == 10) {
if (A_4 < A_10) {
min = 4;
}
}
else if (min == 11) {
if (A_4 < A_11) {
min = 4;
}
}
else if (min == 12) {
if (A_4 < A_12) {
min = 4;
}
}
else if (min == 13) {
if (A_4 < A_13) {
min = 4;
}
}
else if (min == 14) {
if (A_4 < A_14) {
min = 4;
}
}
}
else if (j == 5) {
if (min == 0) {
if (A_5 < A_0) {
min = 5;
}
}
else if (min == 1) {
if (A_5 < A_1) {
min = 5;
}
}
else if (min == 2) {
if (A_5 < A_2) {
min = 5;
}
}
else if (min == 3) {
if (A_5 < A_3) {
min = 5;
}
}
else if (min == 4) {
if (A_5 < A_4) {
min = 5;
}
}
else if (min == 5) {
if (A_5 < A_5) {
min = 5;
}
}
else if (min == 6) {
if (A_5 < A_6) {
min = 5;
}
}
else if (min == 7) {
if (A_5 < A_7) {
min = 5;
}
}
else if (min == 8) {
if (A_5 < A_8) {
min = 5;
}
}
else if (min == 9) {
if (A_5 < A_9) {
min = 5;
}
}
else if (min == 10) {
if (A_5 < A_10) {
min = 5;
}
}
else if (min == 11) {
if (A_5 < A_11) {
min = 5;
}
}
else if (min == 12) {
if (A_5 < A_12) {
min = 5;
}
}
else if (min == 13) {
if (A_5 < A_13) {
min = 5;
}
}
else if (min == 14) {
if (A_5 < A_14) {
min = 5;
}
}
}
else if (j == 6) {
if (min == 0) {
if (A_6 < A_0) {
min = 6;
}
}
else if (min == 1) {
if (A_6 < A_1) {
min = 6;
}
}
else if (min == 2) {
if (A_6 < A_2) {
min = 6;
}
}
else if (min == 3) {
if (A_6 < A_3) {
min = 6;
}
}
else if (min == 4) {
if (A_6 < A_4) {
min = 6;
}
}
else if (min == 5) {
if (A_6 < A_5) {
min = 6;
}
}
else if (min == 6) {
if (A_6 < A_6) {
min = 6;
}
}
else if (min == 7) {
if (A_6 < A_7) {
min = 6;
}
}
else if (min == 8) {
if (A_6 < A_8) {
min = 6;
}
}
else if (min == 9) {
if (A_6 < A_9) {
min = 6;
}
}
else if (min == 10) {
if (A_6 < A_10) {
min = 6;
}
}
else if (min == 11) {
if (A_6 < A_11) {
min = 6;
}
}
else if (min == 12) {
if (A_6 < A_12) {
min = 6;
}
}
else if (min == 13) {
if (A_6 < A_13) {
min = 6;
}
}
else if (min == 14) {
if (A_6 < A_14) {
min = 6;
}
}
}
else if (j == 7) {
if (min == 0) {
if (A_7 < A_0) {
min = 7;
}
}
else if (min == 1) {
if (A_7 < A_1) {
min = 7;
}
}
else if (min == 2) {
if (A_7 < A_2) {
min = 7;
}
}
else if (min == 3) {
if (A_7 < A_3) {
min = 7;
}
}
else if (min == 4) {
if (A_7 < A_4) {
min = 7;
}
}
else if (min == 5) {
if (A_7 < A_5) {
min = 7;
}
}
else if (min == 6) {
if (A_7 < A_6) {
min = 7;
}
}
else if (min == 7) {
if (A_7 < A_7) {
min = 7;
}
}
else if (min == 8) {
if (A_7 < A_8) {
min = 7;
}
}
else if (min == 9) {
if (A_7 < A_9) {
min = 7;
}
}
else if (min == 10) {
if (A_7 < A_10) {
min = 7;
}
}
else if (min == 11) {
if (A_7 < A_11) {
min = 7;
}
}
else if (min == 12) {
if (A_7 < A_12) {
min = 7;
}
}
else if (min == 13) {
if (A_7 < A_13) {
min = 7;
}
}
else if (min == 14) {
if (A_7 < A_14) {
min = 7;
}
}
}
else if (j == 8) {
if (min == 0) {
if (A_8 < A_0) {
min = 8;
}
}
else if (min == 1) {
if (A_8 < A_1) {
min = 8;
}
}
else if (min == 2) {
if (A_8 < A_2) {
min = 8;
}
}
else if (min == 3) {
if (A_8 < A_3) {
min = 8;
}
}
else if (min == 4) {
if (A_8 < A_4) {
min = 8;
}
}
else if (min == 5) {
if (A_8 < A_5) {
min = 8;
}
}
else if (min == 6) {
if (A_8 < A_6) {
min = 8;
}
}
else if (min == 7) {
if (A_8 < A_7) {
min = 8;
}
}
else if (min == 8) {
if (A_8 < A_8) {
min = 8;
}
}
else if (min == 9) {
if (A_8 < A_9) {
min = 8;
}
}
else if (min == 10) {
if (A_8 < A_10) {
min = 8;
}
}
else if (min == 11) {
if (A_8 < A_11) {
min = 8;
}
}
else if (min == 12) {
if (A_8 < A_12) {
min = 8;
}
}
else if (min == 13) {
if (A_8 < A_13) {
min = 8;
}
}
else if (min == 14) {
if (A_8 < A_14) {
min = 8;
}
}
}
else if (j == 9) {
if (min == 0) {
if (A_9 < A_0) {
min = 9;
}
}
else if (min == 1) {
if (A_9 < A_1) {
min = 9;
}
}
else if (min == 2) {
if (A_9 < A_2) {
min = 9;
}
}
else if (min == 3) {
if (A_9 < A_3) {
min = 9;
}
}
else if (min == 4) {
if (A_9 < A_4) {
min = 9;
}
}
else if (min == 5) {
if (A_9 < A_5) {
min = 9;
}
}
else if (min == 6) {
if (A_9 < A_6) {
min = 9;
}
}
else if (min == 7) {
if (A_9 < A_7) {
min = 9;
}
}
else if (min == 8) {
if (A_9 < A_8) {
min = 9;
}
}
else if (min == 9) {
if (A_9 < A_9) {
min = 9;
}
}
else if (min == 10) {
if (A_9 < A_10) {
min = 9;
}
}
else if (min == 11) {
if (A_9 < A_11) {
min = 9;
}
}
else if (min == 12) {
if (A_9 < A_12) {
min = 9;
}
}
else if (min == 13) {
if (A_9 < A_13) {
min = 9;
}
}
else if (min == 14) {
if (A_9 < A_14) {
min = 9;
}
}
}
else if (j == 10) {
if (min == 0) {
if (A_10 < A_0) {
min = 10;
}
}
else if (min == 1) {
if (A_10 < A_1) {
min = 10;
}
}
else if (min == 2) {
if (A_10 < A_2) {
min = 10;
}
}
else if (min == 3) {
if (A_10 < A_3) {
min = 10;
}
}
else if (min == 4) {
if (A_10 < A_4) {
min = 10;
}
}
else if (min == 5) {
if (A_10 < A_5) {
min = 10;
}
}
else if (min == 6) {
if (A_10 < A_6) {
min = 10;
}
}
else if (min == 7) {
if (A_10 < A_7) {
min = 10;
}
}
else if (min == 8) {
if (A_10 < A_8) {
min = 10;
}
}
else if (min == 9) {
if (A_10 < A_9) {
min = 10;
}
}
else if (min == 10) {
if (A_10 < A_10) {
min = 10;
}
}
else if (min == 11) {
if (A_10 < A_11) {
min = 10;
}
}
else if (min == 12) {
if (A_10 < A_12) {
min = 10;
}
}
else if (min == 13) {
if (A_10 < A_13) {
min = 10;
}
}
else if (min == 14) {
if (A_10 < A_14) {
min = 10;
}
}
}
else if (j == 11) {
if (min == 0) {
if (A_11 < A_0) {
min = 11;
}
}
else if (min == 1) {
if (A_11 < A_1) {
min = 11;
}
}
else if (min == 2) {
if (A_11 < A_2) {
min = 11;
}
}
else if (min == 3) {
if (A_11 < A_3) {
min = 11;
}
}
else if (min == 4) {
if (A_11 < A_4) {
min = 11;
}
}
else if (min == 5) {
if (A_11 < A_5) {
min = 11;
}
}
else if (min == 6) {
if (A_11 < A_6) {
min = 11;
}
}
else if (min == 7) {
if (A_11 < A_7) {
min = 11;
}
}
else if (min == 8) {
if (A_11 < A_8) {
min = 11;
}
}
else if (min == 9) {
if (A_11 < A_9) {
min = 11;
}
}
else if (min == 10) {
if (A_11 < A_10) {
min = 11;
}
}
else if (min == 11) {
if (A_11 < A_11) {
min = 11;
}
}
else if (min == 12) {
if (A_11 < A_12) {
min = 11;
}
}
else if (min == 13) {
if (A_11 < A_13) {
min = 11;
}
}
else if (min == 14) {
if (A_11 < A_14) {
min = 11;
}
}
}
else if (j == 12) {
if (min == 0) {
if (A_12 < A_0) {
min = 12;
}
}
else if (min == 1) {
if (A_12 < A_1) {
min = 12;
}
}
else if (min == 2) {
if (A_12 < A_2) {
min = 12;
}
}
else if (min == 3) {
if (A_12 < A_3) {
min = 12;
}
}
else if (min == 4) {
if (A_12 < A_4) {
min = 12;
}
}
else if (min == 5) {
if (A_12 < A_5) {
min = 12;
}
}
else if (min == 6) {
if (A_12 < A_6) {
min = 12;
}
}
else if (min == 7) {
if (A_12 < A_7) {
min = 12;
}
}
else if (min == 8) {
if (A_12 < A_8) {
min = 12;
}
}
else if (min == 9) {
if (A_12 < A_9) {
min = 12;
}
}
else if (min == 10) {
if (A_12 < A_10) {
min = 12;
}
}
else if (min == 11) {
if (A_12 < A_11) {
min = 12;
}
}
else if (min == 12) {
if (A_12 < A_12) {
min = 12;
}
}
else if (min == 13) {
if (A_12 < A_13) {
min = 12;
}
}
else if (min == 14) {
if (A_12 < A_14) {
min = 12;
}
}
}
else if (j == 13) {
if (min == 0) {
if (A_13 < A_0) {
min = 13;
}
}
else if (min == 1) {
if (A_13 < A_1) {
min = 13;
}
}
else if (min == 2) {
if (A_13 < A_2) {
min = 13;
}
}
else if (min == 3) {
if (A_13 < A_3) {
min = 13;
}
}
else if (min == 4) {
if (A_13 < A_4) {
min = 13;
}
}
else if (min == 5) {
if (A_13 < A_5) {
min = 13;
}
}
else if (min == 6) {
if (A_13 < A_6) {
min = 13;
}
}
else if (min == 7) {
if (A_13 < A_7) {
min = 13;
}
}
else if (min == 8) {
if (A_13 < A_8) {
min = 13;
}
}
else if (min == 9) {
if (A_13 < A_9) {
min = 13;
}
}
else if (min == 10) {
if (A_13 < A_10) {
min = 13;
}
}
else if (min == 11) {
if (A_13 < A_11) {
min = 13;
}
}
else if (min == 12) {
if (A_13 < A_12) {
min = 13;
}
}
else if (min == 13) {
if (A_13 < A_13) {
min = 13;
}
}
else if (min == 14) {
if (A_13 < A_14) {
min = 13;
}
}
}
else if (j == 14) {
if (min == 0) {
if (A_14 < A_0) {
min = 14;
}
}
else if (min == 1) {
if (A_14 < A_1) {
min = 14;
}
}
else if (min == 2) {
if (A_14 < A_2) {
min = 14;
}
}
else if (min == 3) {
if (A_14 < A_3) {
min = 14;
}
}
else if (min == 4) {
if (A_14 < A_4) {
min = 14;
}
}
else if (min == 5) {
if (A_14 < A_5) {
min = 14;
}
}
else if (min == 6) {
if (A_14 < A_6) {
min = 14;
}
}
else if (min == 7) {
if (A_14 < A_7) {
min = 14;
}
}
else if (min == 8) {
if (A_14 < A_8) {
min = 14;
}
}
else if (min == 9) {
if (A_14 < A_9) {
min = 14;
}
}
else if (min == 10) {
if (A_14 < A_10) {
min = 14;
}
}
else if (min == 11) {
if (A_14 < A_11) {
min = 14;
}
}
else if (min == 12) {
if (A_14 < A_12) {
min = 14;
}
}
else if (min == 13) {
if (A_14 < A_13) {
min = 14;
}
}
else if (min == 14) {
if (A_14 < A_14) {
min = 14;
}
}
}
j = j + 1;
}
if (i == 0) {
if (min == 0) {
t = A_0;
A_0 = A_0;
A_0 = t;
}
else if (min == 1) {
t = A_1;
A_1 = A_0;
A_0 = t;
}
else if (min == 2) {
t = A_2;
A_2 = A_0;
A_0 = t;
}
else if (min == 3) {
t = A_3;
A_3 = A_0;
A_0 = t;
}
else if (min == 4) {
t = A_4;
A_4 = A_0;
A_0 = t;
}
else if (min == 5) {
t = A_5;
A_5 = A_0;
A_0 = t;
}
else if (min == 6) {
t = A_6;
A_6 = A_0;
A_0 = t;
}
else if (min == 7) {
t = A_7;
A_7 = A_0;
A_0 = t;
}
else if (min == 8) {
t = A_8;
A_8 = A_0;
A_0 = t;
}
else if (min == 9) {
t = A_9;
A_9 = A_0;
A_0 = t;
}
else if (min == 10) {
t = A_10;
A_10 = A_0;
A_0 = t;
}
else if (min == 11) {
t = A_11;
A_11 = A_0;
A_0 = t;
}
else if (min == 12) {
t = A_12;
A_12 = A_0;
A_0 = t;
}
else if (min == 13) {
t = A_13;
A_13 = A_0;
A_0 = t;
}
else if (min == 14) {
t = A_14;
A_14 = A_0;
A_0 = t;
}
}
else if (i == 1) {
if (min == 0) {
t = A_0;
A_0 = A_1;
A_1 = t;
}
else if (min == 1) {
t = A_1;
A_1 = A_1;
A_1 = t;
}
else if (min == 2) {
t = A_2;
A_2 = A_1;
A_1 = t;
}
else if (min == 3) {
t = A_3;
A_3 = A_1;
A_1 = t;
}
else if (min == 4) {
t = A_4;
A_4 = A_1;
A_1 = t;
}
else if (min == 5) {
t = A_5;
A_5 = A_1;
A_1 = t;
}
else if (min == 6) {
t = A_6;
A_6 = A_1;
A_1 = t;
}
else if (min == 7) {
t = A_7;
A_7 = A_1;
A_1 = t;
}
else if (min == 8) {
t = A_8;
A_8 = A_1;
A_1 = t;
}
else if (min == 9) {
t = A_9;
A_9 = A_1;
A_1 = t;
}
else if (min == 10) {
t = A_10;
A_10 = A_1;
A_1 = t;
}
else if (min == 11) {
t = A_11;
A_11 = A_1;
A_1 = t;
}
else if (min == 12) {
t = A_12;
A_12 = A_1;
A_1 = t;
}
else if (min == 13) {
t = A_13;
A_13 = A_1;
A_1 = t;
}
else if (min == 14) {
t = A_14;
A_14 = A_1;
A_1 = t;
}
}
else if (i == 2) {
if (min == 0) {
t = A_0;
A_0 = A_2;
A_2 = t;
}
else if (min == 1) {
t = A_1;
A_1 = A_2;
A_2 = t;
}
else if (min == 2) {
t = A_2;
A_2 = A_2;
A_2 = t;
}
else if (min == 3) {
t = A_3;
A_3 = A_2;
A_2 = t;
}
else if (min == 4) {
t = A_4;
A_4 = A_2;
A_2 = t;
}
else if (min == 5) {
t = A_5;
A_5 = A_2;
A_2 = t;
}
else if (min == 6) {
t = A_6;
A_6 = A_2;
A_2 = t;
}
else if (min == 7) {
t = A_7;
A_7 = A_2;
A_2 = t;
}
else if (min == 8) {
t = A_8;
A_8 = A_2;
A_2 = t;
}
else if (min == 9) {
t = A_9;
A_9 = A_2;
A_2 = t;
}
else if (min == 10) {
t = A_10;
A_10 = A_2;
A_2 = t;
}
else if (min == 11) {
t = A_11;
A_11 = A_2;
A_2 = t;
}
else if (min == 12) {
t = A_12;
A_12 = A_2;
A_2 = t;
}
else if (min == 13) {
t = A_13;
A_13 = A_2;
A_2 = t;
}
else if (min == 14) {
t = A_14;
A_14 = A_2;
A_2 = t;
}
}
else if (i == 3) {
if (min == 0) {
t = A_0;
A_0 = A_3;
A_3 = t;
}
else if (min == 1) {
t = A_1;
A_1 = A_3;
A_3 = t;
}
else if (min == 2) {
t = A_2;
A_2 = A_3;
A_3 = t;
}
else if (min == 3) {
t = A_3;
A_3 = A_3;
A_3 = t;
}
else if (min == 4) {
t = A_4;
A_4 = A_3;
A_3 = t;
}
else if (min == 5) {
t = A_5;
A_5 = A_3;
A_3 = t;
}
else if (min == 6) {
t = A_6;
A_6 = A_3;
A_3 = t;
}
else if (min == 7) {
t = A_7;
A_7 = A_3;
A_3 = t;
}
else if (min == 8) {
t = A_8;
A_8 = A_3;
A_3 = t;
}
else if (min == 9) {
t = A_9;
A_9 = A_3;
A_3 = t;
}
else if (min == 10) {
t = A_10;
A_10 = A_3;
A_3 = t;
}
else if (min == 11) {
t = A_11;
A_11 = A_3;
A_3 = t;
}
else if (min == 12) {
t = A_12;
A_12 = A_3;
A_3 = t;
}
else if (min == 13) {
t = A_13;
A_13 = A_3;
A_3 = t;
}
else if (min == 14) {
t = A_14;
A_14 = A_3;
A_3 = t;
}
}
else if (i == 4) {
if (min == 0) {
t = A_0;
A_0 = A_4;
A_4 = t;
}
else if (min == 1) {
t = A_1;
A_1 = A_4;
A_4 = t;
}
else if (min == 2) {
t = A_2;
A_2 = A_4;
A_4 = t;
}
else if (min == 3) {
t = A_3;
A_3 = A_4;
A_4 = t;
}
else if (min == 4) {
t = A_4;
A_4 = A_4;
A_4 = t;
}
else if (min == 5) {
t = A_5;
A_5 = A_4;
A_4 = t;
}
else if (min == 6) {
t = A_6;
A_6 = A_4;
A_4 = t;
}
else if (min == 7) {
t = A_7;
A_7 = A_4;
A_4 = t;
}
else if (min == 8) {
t = A_8;
A_8 = A_4;
A_4 = t;
}
else if (min == 9) {
t = A_9;
A_9 = A_4;
A_4 = t;
}
else if (min == 10) {
t = A_10;
A_10 = A_4;
A_4 = t;
}
else if (min == 11) {
t = A_11;
A_11 = A_4;
A_4 = t;
}
else if (min == 12) {
t = A_12;
A_12 = A_4;
A_4 = t;
}
else if (min == 13) {
t = A_13;
A_13 = A_4;
A_4 = t;
}
else if (min == 14) {
t = A_14;
A_14 = A_4;
A_4 = t;
}
}
else if (i == 5) {
if (min == 0) {
t = A_0;
A_0 = A_5;
A_5 = t;
}
else if (min == 1) {
t = A_1;
A_1 = A_5;
A_5 = t;
}
else if (min == 2) {
t = A_2;
A_2 = A_5;
A_5 = t;
}
else if (min == 3) {
t = A_3;
A_3 = A_5;
A_5 = t;
}
else if (min == 4) {
t = A_4;
A_4 = A_5;
A_5 = t;
}
else if (min == 5) {
t = A_5;
A_5 = A_5;
A_5 = t;
}
else if (min == 6) {
t = A_6;
A_6 = A_5;
A_5 = t;
}
else if (min == 7) {
t = A_7;
A_7 = A_5;
A_5 = t;
}
else if (min == 8) {
t = A_8;
A_8 = A_5;
A_5 = t;
}
else if (min == 9) {
t = A_9;
A_9 = A_5;
A_5 = t;
}
else if (min == 10) {
t = A_10;
A_10 = A_5;
A_5 = t;
}
else if (min == 11) {
t = A_11;
A_11 = A_5;
A_5 = t;
}
else if (min == 12) {
t = A_12;
A_12 = A_5;
A_5 = t;
}
else if (min == 13) {
t = A_13;
A_13 = A_5;
A_5 = t;
}
else if (min == 14) {
t = A_14;
A_14 = A_5;
A_5 = t;
}
}
else if (i == 6) {
if (min == 0) {
t = A_0;
A_0 = A_6;
A_6 = t;
}
else if (min == 1) {
t = A_1;
A_1 = A_6;
A_6 = t;
}
else if (min == 2) {
t = A_2;
A_2 = A_6;
A_6 = t;
}
else if (min == 3) {
t = A_3;
A_3 = A_6;
A_6 = t;
}
else if (min == 4) {
t = A_4;
A_4 = A_6;
A_6 = t;
}
else if (min == 5) {
t = A_5;
A_5 = A_6;
A_6 = t;
}
else if (min == 6) {
t = A_6;
A_6 = A_6;
A_6 = t;
}
else if (min == 7) {
t = A_7;
A_7 = A_6;
A_6 = t;
}
else if (min == 8) {
t = A_8;
A_8 = A_6;
A_6 = t;
}
else if (min == 9) {
t = A_9;
A_9 = A_6;
A_6 = t;
}
else if (min == 10) {
t = A_10;
A_10 = A_6;
A_6 = t;
}
else if (min == 11) {
t = A_11;
A_11 = A_6;
A_6 = t;
}
else if (min == 12) {
t = A_12;
A_12 = A_6;
A_6 = t;
}
else if (min == 13) {
t = A_13;
A_13 = A_6;
A_6 = t;
}
else if (min == 14) {
t = A_14;
A_14 = A_6;
A_6 = t;
}
}
else if (i == 7) {
if (min == 0) {
t = A_0;
A_0 = A_7;
A_7 = t;
}
else if (min == 1) {
t = A_1;
A_1 = A_7;
A_7 = t;
}
else if (min == 2) {
t = A_2;
A_2 = A_7;
A_7 = t;
}
else if (min == 3) {
t = A_3;
A_3 = A_7;
A_7 = t;
}
else if (min == 4) {
t = A_4;
A_4 = A_7;
A_7 = t;
}
else if (min == 5) {
t = A_5;
A_5 = A_7;
A_7 = t;
}
else if (min == 6) {
t = A_6;
A_6 = A_7;
A_7 = t;
}
else if (min == 7) {
t = A_7;
A_7 = A_7;
A_7 = t;
}
else if (min == 8) {
t = A_8;
A_8 = A_7;
A_7 = t;
}
else if (min == 9) {
t = A_9;
A_9 = A_7;
A_7 = t;
}
else if (min == 10) {
t = A_10;
A_10 = A_7;
A_7 = t;
}
else if (min == 11) {
t = A_11;
A_11 = A_7;
A_7 = t;
}
else if (min == 12) {
t = A_12;
A_12 = A_7;
A_7 = t;
}
else if (min == 13) {
t = A_13;
A_13 = A_7;
A_7 = t;
}
else if (min == 14) {
t = A_14;
A_14 = A_7;
A_7 = t;
}
}
else if (i == 8) {
if (min == 0) {
t = A_0;
A_0 = A_8;
A_8 = t;
}
else if (min == 1) {
t = A_1;
A_1 = A_8;
A_8 = t;
}
else if (min == 2) {
t = A_2;
A_2 = A_8;
A_8 = t;
}
else if (min == 3) {
t = A_3;
A_3 = A_8;
A_8 = t;
}
else if (min == 4) {
t = A_4;
A_4 = A_8;
A_8 = t;
}
else if (min == 5) {
t = A_5;
A_5 = A_8;
A_8 = t;
}
else if (min == 6) {
t = A_6;
A_6 = A_8;
A_8 = t;
}
else if (min == 7) {
t = A_7;
A_7 = A_8;
A_8 = t;
}
else if (min == 8) {
t = A_8;
A_8 = A_8;
A_8 = t;
}
else if (min == 9) {
t = A_9;
A_9 = A_8;
A_8 = t;
}
else if (min == 10) {
t = A_10;
A_10 = A_8;
A_8 = t;
}
else if (min == 11) {
t = A_11;
A_11 = A_8;
A_8 = t;
}
else if (min == 12) {
t = A_12;
A_12 = A_8;
A_8 = t;
}
else if (min == 13) {
t = A_13;
A_13 = A_8;
A_8 = t;
}
else if (min == 14) {
t = A_14;
A_14 = A_8;
A_8 = t;
}
}
else if (i == 9) {
if (min == 0) {
t = A_0;
A_0 = A_9;
A_9 = t;
}
else if (min == 1) {
t = A_1;
A_1 = A_9;
A_9 = t;
}
else if (min == 2) {
t = A_2;
A_2 = A_9;
A_9 = t;
}
else if (min == 3) {
t = A_3;
A_3 = A_9;
A_9 = t;
}
else if (min == 4) {
t = A_4;
A_4 = A_9;
A_9 = t;
}
else if (min == 5) {
t = A_5;
A_5 = A_9;
A_9 = t;
}
else if (min == 6) {
t = A_6;
A_6 = A_9;
A_9 = t;
}
else if (min == 7) {
t = A_7;
A_7 = A_9;
A_9 = t;
}
else if (min == 8) {
t = A_8;
A_8 = A_9;
A_9 = t;
}
else if (min == 9) {
t = A_9;
A_9 = A_9;
A_9 = t;
}
else if (min == 10) {
t = A_10;
A_10 = A_9;
A_9 = t;
}
else if (min == 11) {
t = A_11;
A_11 = A_9;
A_9 = t;
}
else if (min == 12) {
t = A_12;
A_12 = A_9;
A_9 = t;
}
else if (min == 13) {
t = A_13;
A_13 = A_9;
A_9 = t;
}
else if (min == 14) {
t = A_14;
A_14 = A_9;
A_9 = t;
}
}
else if (i == 10) {
if (min == 0) {
t = A_0;
A_0 = A_10;
A_10 = t;
}
else if (min == 1) {
t = A_1;
A_1 = A_10;
A_10 = t;
}
else if (min == 2) {
t = A_2;
A_2 = A_10;
A_10 = t;
}
else if (min == 3) {
t = A_3;
A_3 = A_10;
A_10 = t;
}
else if (min == 4) {
t = A_4;
A_4 = A_10;
A_10 = t;
}
else if (min == 5) {
t = A_5;
A_5 = A_10;
A_10 = t;
}
else if (min == 6) {
t = A_6;
A_6 = A_10;
A_10 = t;
}
else if (min == 7) {
t = A_7;
A_7 = A_10;
A_10 = t;
}
else if (min == 8) {
t = A_8;
A_8 = A_10;
A_10 = t;
}
else if (min == 9) {
t = A_9;
A_9 = A_10;
A_10 = t;
}
else if (min == 10) {
t = A_10;
A_10 = A_10;
A_10 = t;
}
else if (min == 11) {
t = A_11;
A_11 = A_10;
A_10 = t;
}
else if (min == 12) {
t = A_12;
A_12 = A_10;
A_10 = t;
}
else if (min == 13) {
t = A_13;
A_13 = A_10;
A_10 = t;
}
else if (min == 14) {
t = A_14;
A_14 = A_10;
A_10 = t;
}
}
else if (i == 11) {
if (min == 0) {
t = A_0;
A_0 = A_11;
A_11 = t;
}
else if (min == 1) {
t = A_1;
A_1 = A_11;
A_11 = t;
}
else if (min == 2) {
t = A_2;
A_2 = A_11;
A_11 = t;
}
else if (min == 3) {
t = A_3;
A_3 = A_11;
A_11 = t;
}
else if (min == 4) {
t = A_4;
A_4 = A_11;
A_11 = t;
}
else if (min == 5) {
t = A_5;
A_5 = A_11;
A_11 = t;
}
else if (min == 6) {
t = A_6;
A_6 = A_11;
A_11 = t;
}
else if (min == 7) {
t = A_7;
A_7 = A_11;
A_11 = t;
}
else if (min == 8) {
t = A_8;
A_8 = A_11;
A_11 = t;
}
else if (min == 9) {
t = A_9;
A_9 = A_11;
A_11 = t;
}
else if (min == 10) {
t = A_10;
A_10 = A_11;
A_11 = t;
}
else if (min == 11) {
t = A_11;
A_11 = A_11;
A_11 = t;
}
else if (min == 12) {
t = A_12;
A_12 = A_11;
A_11 = t;
}
else if (min == 13) {
t = A_13;
A_13 = A_11;
A_11 = t;
}
else if (min == 14) {
t = A_14;
A_14 = A_11;
A_11 = t;
}
}
else if (i == 12) {
if (min == 0) {
t = A_0;
A_0 = A_12;
A_12 = t;
}
else if (min == 1) {
t = A_1;
A_1 = A_12;
A_12 = t;
}
else if (min == 2) {
t = A_2;
A_2 = A_12;
A_12 = t;
}
else if (min == 3) {
t = A_3;
A_3 = A_12;
A_12 = t;
}
else if (min == 4) {
t = A_4;
A_4 = A_12;
A_12 = t;
}
else if (min == 5) {
t = A_5;
A_5 = A_12;
A_12 = t;
}
else if (min == 6) {
t = A_6;
A_6 = A_12;
A_12 = t;
}
else if (min == 7) {
t = A_7;
A_7 = A_12;
A_12 = t;
}
else if (min == 8) {
t = A_8;
A_8 = A_12;
A_12 = t;
}
else if (min == 9) {
t = A_9;
A_9 = A_12;
A_12 = t;
}
else if (min == 10) {
t = A_10;
A_10 = A_12;
A_12 = t;
}
else if (min == 11) {
t = A_11;
A_11 = A_12;
A_12 = t;
}
else if (min == 12) {
t = A_12;
A_12 = A_12;
A_12 = t;
}
else if (min == 13) {
t = A_13;
A_13 = A_12;
A_12 = t;
}
else if (min == 14) {
t = A_14;
A_14 = A_12;
A_12 = t;
}
}
else if (i == 13) {
if (min == 0) {
t = A_0;
A_0 = A_13;
A_13 = t;
}
else if (min == 1) {
t = A_1;
A_1 = A_13;
A_13 = t;
}
else if (min == 2) {
t = A_2;
A_2 = A_13;
A_13 = t;
}
else if (min == 3) {
t = A_3;
A_3 = A_13;
A_13 = t;
}
else if (min == 4) {
t = A_4;
A_4 = A_13;
A_13 = t;
}
else if (min == 5) {
t = A_5;
A_5 = A_13;
A_13 = t;
}
else if (min == 6) {
t = A_6;
A_6 = A_13;
A_13 = t;
}
else if (min == 7) {
t = A_7;
A_7 = A_13;
A_13 = t;
}
else if (min == 8) {
t = A_8;
A_8 = A_13;
A_13 = t;
}
else if (min == 9) {
t = A_9;
A_9 = A_13;
A_13 = t;
}
else if (min == 10) {
t = A_10;
A_10 = A_13;
A_13 = t;
}
else if (min == 11) {
t = A_11;
A_11 = A_13;
A_13 = t;
}
else if (min == 12) {
t = A_12;
A_12 = A_13;
A_13 = t;
}
else if (min == 13) {
t = A_13;
A_13 = A_13;
A_13 = t;
}
else if (min == 14) {
t = A_14;
A_14 = A_13;
A_13 = t;
}
}
printarray();
i = i + 1;
}
}
void printarray()
{
int i;
i = 0;
while (i <= 14) {
if (i == 0) {
printi(A_0);
prints(" ");
}
else if (i == 1) {
printi(A_1);
prints(" ");
}
else if (i == 2) {
printi(A_2);
prints(" ");
}
else if (i == 3) {
printi(A_3);
prints(" ");
}
else if (i == 4) {
printi(A_4);
prints(" ");
}
else if (i == 5) {
printi(A_5);
prints(" ");
}
else if (i == 6) {
printi(A_6);
prints(" ");
}
else if (i == 7) {
printi(A_7);
prints(" ");
}
else if (i == 8) {
printi(A_8);
prints(" ");
}
else if (i == 9) {
printi(A_9);
prints(" ");
}
else if (i == 10) {
printi(A_10);
prints(" ");
}
else if (i == 11) {
printi(A_11);
prints(" ");
}
else if (i == 12) {
printi(A_12);
prints(" ");
}
else if (i == 13) {
printi(A_13);
prints(" ");
}
else if (i == 14) {
printi(A_14);
prints(" ");
}
i = i + 1;
}
prints("\n");
}

	int INTERNALX;

	void INTERNALseed(int seed) {
		INTERNALX = seed;
	}
	

	//
	//  Linear congruential method of generating pseudorandom
	//  numbers, from Knuth's _The Art of Computer Programming, Volume 2:
	//  Seminumerical Algorithms_, 3rd edition, Addison-Wesley, 1998.
	//  Constants are chosen using Theorem A on page 17.
	//
	//  XXX - the period is long, but the lsb isn't random!
	//
	int INTERNALrandom() {
		INTERNALX = (17 * INTERNALX + 13) % 32768;
		return INTERNALX;
	}
	
