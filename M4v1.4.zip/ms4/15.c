// system calls
main() {
  printb(true);
  prints("\n");
  printb(false);
  prints("\n");
  printc(42);
  prints("\n");
  printi(99);
  prints("\n");
  prints("String");
  prints("\n");
  printc(getchar());
  halt();
  prints("Cannot reach Here");
  prints("and here\n");
}
