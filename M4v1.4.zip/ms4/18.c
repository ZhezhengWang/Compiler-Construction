main() {
  if (false) {
    prints("1\n");
  } else if (true){
    prints("2\n");
  } else {
    prints("3\n");
  }
}