// system calls


int f(int a, int b, int c, int d) {
  int e;
  int f;
  int g;
//  a = 10;
//  b = 20;
//  c = 30;
//  d = 40;
  e = 50;
  f = 60;
  g = 70;
  
  printi(a);
  prints("\n");
  printi(b);
  prints("\n");
  printi(c);
  prints("\n");
  printi(d);
  prints("\n");
  printi(e);
  prints("\n");
  printi(f);
  prints("\n");
  printi(g);
  prints("\n");
  return b;
}

main() {
  f(1, 2, 3, 4);
//  printi(f(true));
//  prints("\n");
//  printi(f(false));
//  prints("\n");

}
