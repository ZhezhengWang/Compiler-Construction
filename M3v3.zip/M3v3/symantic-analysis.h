#ifndef _SYMANTIC_ANALYSIS_H
#define _SYMANTIC_ANALYSIS_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "jmm-types.h"


#define SYMTAB_SIZE 1024

typedef struct SymTabNode_t {
  ASTNode *astNode;
  char *name;
  int lineno;
  ASTNodeExpType type;
  struct SymTabScope_t *scope;
  struct SymTabNode_t *next;
} SymTabNode;

typedef struct SymTabScope_t {
  char *name;
  SymTabNode *entries[SYMTAB_SIZE];
  struct SymTabScope_t *next;
} SymTabScope;


void printMainGlobalError(char *name);
void setExpTypeWithASTNode(ASTNode *n, ASTNode *typeNode);
void setExpType(ASTNode *n, ASTNodeExpType type);
int setExpTypeFromSymbolTable(ASTNode *node, char *name, SymTabScope *localScope);
void checkParametesAndSetFunctionType(ASTNode *funcCall, int pass);
SymTabScope * createScope(char *name);
unsigned int calcSymbolHash(char *name);
void addSymbol(ASTNode *node, SymTabScope *scope, char *name, ASTNodeType ntype);
SymTabNode * lookupSymbol(char *name, SymTabScope *scope);
void checkMainExists();
void checkMainType(char *sym);
void checkReturn(ASTNode *node);
void checkMissingReturn();
void traverseParseTree(ASTNode *root, SymTabScope *localScope, int pass, int blockLevel, int whileLevel);


#endif /* _SYMANTIC_ANALYSIS_H */
