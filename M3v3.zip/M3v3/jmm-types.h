#ifndef __JMM_TYPES__
#define __JMM_TYPES__


int yylex();
void yyerror(const char* str);
extern char *yytext;
extern int yylineno;

typedef enum ASTNodeType_t {
	AST_PROGRAM = 0,
	AST_GLOBAL_VAR_DECL,
	AST_VAR_DECL,
	AST_FUNC_DECL,
	AST_FUNC_CALL,
	AST_FORMALS,
	AST_FORMAL,
	AST_ACTUALS,
	AST_VOID,
	AST_INT,
	AST_BOOLEAN,
	AST_STRING,
	AST_ID,
	AST_NUMBER,
	AST_BLOCK,
	AST_STMT_EXPR,
	AST_RETURN,
	AST_BREAK,
	AST_IF,
	AST_IF_ELSE,
	AST_SUB,
	AST_PLUS,
	AST_MUL,
	AST_DIV,
	AST_MOD,
	AST_LT,
	AST_GT,
	AST_LE,
	AST_GE,
	AST_EQ,
	AST_NE,
	AST_NOT,
	AST_USUB,
	AST_TRUE,
	AST_FALSE,
	AST_NULL_STMT,
	AST_ASSIGN,
	AST_WHILE,
	AST_AND,
	AST_OR,
	AST_MAIN_DECL,
	AST_NONE
} ASTNodeType;


typedef enum ASTNodePrintEnum_t {
	ASTNodePrintType,
	ASTNodePrintLineNo,
	ASTNodePrintAll
} ASTNodePrintEnum;

typedef enum ASTNodeExpType_t {
	VOID_TYPE = AST_VOID,
	INT_TYPE = AST_INT,
	BOOL_TYPE = AST_BOOLEAN,
	STRING_TYPE = AST_STRING,
	FUNC_TYPE = AST_FUNC_DECL,
	NONE_TYPE = 0
} ASTNodeExpType;

typedef struct ASTNode_t {
	ASTNodeType astType;
	ASTNodeExpType expType;
	struct ASTNode_t *next;
	struct ASTNode_t *children;
	char *attr;
	int lineno;
} ASTNode;



#endif /* __JMM_TYPES__ */
