#include "symantic-analysis.h"

#ifdef SYMANTIC_ANALYSIS


extern SymTabScope *global;
extern int yylineno;
extern int errorFlag;
extern ASTNode *program;
extern const char *ASTNodeName[];
extern ASTNode *program;
int returnFound;

int mainFound = 0;

void printMainGlobalError(char *name) {
  if (strcmp("main", name) == 0) {
    errorFlag = 1;
    fprintf(stderr, "cannot declare a global variable with name \"main\"\n");
  }
}



int unknownVariable(ASTNode *v) {
    if (v->astType == AST_ID && v->expType == NONE_TYPE) {
        fprintf(stderr, "Error: line %d -> unknown variable: %s\n", yylineno, v->attr );
        return 1;
    }
    return 0;
}


void checkIfIntType(ASTNode *n, int pass) {
    if (pass == 2 && n->expType != INT_TYPE && !unknownVariable(n)) {
        errorFlag = 1;
        fprintf(stderr, "Error: line %d -> int type expected %s found\n", n->lineno, ASTNodeName[n->expType]);
    } 
}


void checkIfBoolType(ASTNode *n, int pass) {
    if (pass == 2 && n->expType != BOOL_TYPE && !unknownVariable(n)) {
        errorFlag = 1;
        fprintf(stderr, "Error: line %d -> boolean type expected %s found\n", n->lineno, ASTNodeName[n->expType]);
    } 
}


int setExpTypeFromSymbolTable(ASTNode *node, char *name, SymTabScope *localScope) {
    SymTabNode *s = lookupSymbol(name, localScope);
    
    if (!s) {
        s = lookupSymbol(name, global);
    }
    
    if (s) {
        if (s->astNode->astType == AST_FUNC_DECL) {
            node->expType = s->astNode->children->expType;
        } else {
            node->expType = s->astNode->expType;
        }
    }
    
    return !!s;
}

void checkTypeMatch(ASTNode *base, int pass) {
  ASTNode *l = base->children;
  ASTNode *r = l->next;

  if ((l->expType != r->expType) && pass == 2) {
      errorFlag = 1;
      if (!unknownVariable(l) && !unknownVariable(r)) {
        fprintf(stderr, "Error: line %d -> not same type. found: %s, expected: %s\n", base->lineno, ASTNodeName[l->expType], ASTNodeName[r->expType]);
      }
  }
}

void checkIntType(ASTNode *base, int pass) {
  ASTNode *l = base->children;
  ASTNode *r = l->next;

  if ((l->expType != INT_TYPE || r->expType != INT_TYPE) && pass == 2) {
      errorFlag = 1;
      ASTNodeExpType tp = (r->expType != INT_TYPE)?r->expType:l->expType;
      fprintf(stderr, "Error: line %d -> unexpected type for arithmatic operator. found: %s, expected: int\n", base->lineno, ASTNodeName[tp]);
  }
}

void checkBoolType(ASTNode *base, int pass) {
  ASTNode *l = base->children;
  ASTNode *r = l->next;

  if ((l->expType != BOOL_TYPE || r->expType != BOOL_TYPE) && pass == 2) {
      errorFlag = 1;
      ASTNodeExpType tp = (r->expType != BOOL_TYPE)?r->expType:l->expType;
      fprintf(stderr, "Error: line %d -> unexpected type for logical operator. found: %s, expected: boolean\n", base->lineno, ASTNodeName[tp]);
  }
}

void setExpType(ASTNode *n, ASTNodeExpType type) {
    n->expType = type;
}


void setExpTypeWithASTNode(ASTNode *n, ASTNode *typeNode) {

    switch (typeNode->astType) {
        case AST_VOID:     n->expType = VOID_TYPE; break;
        case AST_INT:        n->expType = INT_TYPE; break;
        case AST_BOOLEAN:    n->expType = BOOL_TYPE; break;
        case AST_STRING:    n->expType = STRING_TYPE; break;
        case AST_FUNC_DECL:    n->expType = FUNC_TYPE; break;
        case AST_FUNC_CALL:    
            {
                SymTabNode *s = lookupSymbol(typeNode->children->attr, global);
                if (s) {
                    if (s->astNode->astType == AST_FUNC_DECL) {
                        n->expType = s->astNode->children->astType;
                    }
                }
                break;
            }
        default:
        {}
    }
    
}



SymTabScope * createScope(char *name) {
    SymTabScope *scope;
    
    scope = (SymTabScope *)malloc(sizeof(SymTabScope));
    memset(scope, 0, sizeof(SymTabScope ));
    
    scope->name = name;
    
    return scope;
}


unsigned int calcSymbolHash(char *name) {
    int len = strlen(name);
    unsigned int sum = 0;
    for (int i = 0; i < len; i++) {
        sum += name[i]<<i;
    }
    
    return sum%SYMTAB_SIZE;
}



void addSymbol(ASTNode *node, SymTabScope *scope, char *name, ASTNodeType ntype) {
    SymTabNode **pentry = &(scope->entries[calcSymbolHash(name)]);
    SymTabNode *entry;
    ASTNodeExpType type;
    while (*pentry) pentry = &((*pentry)->next);
    
    *pentry = (SymTabNode *) malloc(sizeof(SymTabNode));
    
    type = (ASTNodeExpType)ntype;
    
    
    //printf("Adding: %s with ntype %s, line: %d\n\n\n", name, ASTNodeName[ntype], yylineno);
    
    entry = *pentry;
    entry->astNode = node;
    entry->name = name;
    entry->type = type;
    entry->lineno = yylineno;
    entry->scope = scope;
    entry->next = NULL;
}

void checkParametesAndSetFunctionType(ASTNode *call, int pass) {
    if (pass != 2)
      return;

    ASTNode *id = call->children;
    char *name = id->attr;
    SymTabNode *s = lookupSymbol(name, global);
    if (s) {
        if (s->astNode->astType == AST_FUNC_DECL) {
            ASTNode *decl = s->astNode;
            ASTNode *decl_type = decl->children;

            call->expType = decl_type->expType;

            if (pass == 2) {
                ASTNode *decl_id = decl_type->next;
                ASTNode *formals = decl_id->next;
                ASTNode *formal_params = formals->children;
                
                ASTNode *call_id = call->children;
                ASTNode *actuals = call_id->next;
                ASTNode *actual_params = actuals->children;
                
                int count = 1;
                while (formal_params && actual_params) {
                    ASTNode *formal_param = formal_params->children;
                    ASTNode *actual_param = actual_params;
                    if (formal_param->expType != actual_param->expType) {
                        errorFlag = 1;
                        fprintf(stderr, "Error: line %d ->  Expected parameter number %d to be type %s, found %s\n", id->lineno, count, ASTNodeName[formal_param->expType], ASTNodeName[actual_param->expType]);
                    }
                    count++;
                    formal_params = formal_params->next;
                    actual_params = actual_params->next;
                }
                
                if (formal_params) {
                    errorFlag = 1;
                    fprintf(stderr, "Error: line %d ->  Insufficient number of parameters\n", id->lineno);
                } else if (actual_params) {
                    errorFlag = 1;
                    fprintf(stderr, "Error: line %d ->  Accessive parameters\n", id->lineno);
                }
                
            }
            
            // check parameters
        }
        else {
            errorFlag = 1;
            if (strcmp(name, "main") == 0) {
              fprintf(stderr, "Error: line %d -> The main function can't be called.\n", id->lineno);
            } else {
              fprintf(stderr, "Error: line %d -> %s is not a function\n", id->lineno, name);
            } 
        }
    } else {
        call->expType = NONE_TYPE;
    }
}


SymTabNode * lookupSymbol(char *name, SymTabScope *scope) {
    SymTabNode *sym = NULL;
    unsigned int index = calcSymbolHash(name);
    
    if (scope) {
        sym = scope->entries[index];
        
        while (sym && strcmp(name, sym->name) != 0) sym = sym->next;
        
        if (sym)
            return sym;
    }

    return NULL;
}
void checkMainType(char *sym) {
  if (strcmp("main", sym) == 0) {
    errorFlag = 1;
    fprintf(stderr, "main function cannot have return type or parameters. \n");
  }
}

void checkMainExists() {
  SymTabNode *mainSym= lookupSymbol("main", global);
  if (!mainSym || mainSym->astNode->astType != AST_MAIN_DECL) {
    errorFlag = 1;
    fprintf(stderr, "No main declaration found.\n");
  }
}

void checkReturnType(ASTNode *ret, SymTabScope *localScope, int pass) {
  ASTNode *retExpr = ret->children;
  if (pass == 2) {
    if (localScope) {
        SymTabNode *sym = lookupSymbol(localScope->name, global);
        if (sym->astNode->astType == AST_FUNC_DECL) {
          ASTNode *decl = sym->astNode;
          ASTNode *decl_type = decl->children;
          
          if (retExpr == NULL) {
            if (decl_type->expType != VOID_TYPE) {
              errorFlag = 1;
              fprintf(stderr, "Line: %d -> return argumtnt not found\n", ret->lineno);
            }
          } else {
              if (decl_type->expType != retExpr->expType) {
                errorFlag = 1;
                fprintf(stderr, "Line: %d -> return type expected %s, found %s\n", ret->lineno, ASTNodeName[decl_type->expType], ASTNodeName[retExpr->expType]);
              }
          }
          
        } else {
          errorFlag = 1;
          fprintf(stderr, "Line: %d -> unknown error\n", ret->lineno);
        }
        
    } else {
      errorFlag = 1;
      fprintf(stderr, "return statement must be inside a function\n");
    }
  }
}

void checkMissingReturn(ASTNode *c, int pass) {
  if (pass == 2 && c->astType == AST_FUNC_DECL) {
    ASTNode *decl_type = c->children;
    if (decl_type->expType != VOID_TYPE && returnFound == 0) {
      errorFlag = 1;
      fprintf(stderr, "Line: %d -> No return statement in a non-void function.\n", c->lineno);
    }
  }
}

void handleMainDecl(ASTNode *c, int pass) {
  if (pass == 1) {
    ASTNode *type = c->children;
    ASTNode *id = type->next;
    if (strcmp(id->attr, "main") != 0) {
      errorFlag = 1;
      fprintf(stderr, "Error Function: '%s' must have a return type at line: %d\n", id->attr, id->lineno);
    } else {
      SymTabNode *s = lookupSymbol("main", global);
      mainFound = 1;
      if (s) {
        errorFlag = 1;
        lookupSymbol("main", global);
        fprintf(stderr, "Error Line: %d - Cannot redeclare main, main function already exists at line: %d\n", c->lineno, s->astNode->lineno);
      } else {
        addSymbol(c, global, "main", AST_FUNC_DECL);
      }
    }
  }
}

void handleGlobalVarDecl(ASTNode *c, int pass) {
  ASTNode *type = c->children;
  ASTNode *id = type->next;
  if (pass == 1) {
      printMainGlobalError(id->attr);
      SymTabNode *s = lookupSymbol(id->attr, global);
      if (s) {
        errorFlag = 1;
        fprintf(stderr, "Error: Cannot declare variable with name: %s, a symbol with the same name already exists. at line: %d\n", id->attr, s->lineno);
      } else {
        addSymbol(c, global, id->attr, type->astType);
      }
    }
}

void handleVarDecl(ASTNode *c, SymTabScope *localScope, int blockLevel, int pass) {
  if (pass == 1) {
    setExpTypeWithASTNode(c, c->children);
    if (blockLevel > 1) {
      errorFlag = 1;
      fprintf(stderr, "Error: line: %d - A local declaration was not in an outermost block.\n", c->lineno);
    }
  }
  ASTNode *type = c->children;
  ASTNode *id = type->next;
  if (pass == 2) {
    if (localScope) {
      SymTabNode *s = lookupSymbol(id->attr, localScope);
      if (s) {
        errorFlag = 1;
        fprintf(stderr, "Error: Cannot declare variable with name: %s, a symbol with the same name already exists. at line: %d, scope: %s\n", id->attr, s->lineno, localScope->name);
      } else {
        addSymbol(c, localScope, id->attr, type->astType);
      }
    }
  }

}

void checkIsInWhile(ASTNode *c, int whileLevel, int pass) {
  if (pass == 1 && !whileLevel) {
    errorFlag = 1;
    fprintf(stderr, "Error: line %d ->  Break statements must be inside a while statement.\n", c->lineno);
  }
}

void handleFuncDecl(ASTNode *c, int pass) {
  ASTNode *type = c->children;
  ASTNode *id = type->next;
  char *name = id->attr;
  setExpTypeWithASTNode(id, type);
  if (pass == 1) {
    checkMainType(id->attr);
    SymTabNode *s = lookupSymbol(name, global);
    if (s) {
      errorFlag = 1;
      fprintf(stderr, "Error at line: %d: Cannot declare function with name: %s, a symbol with the same name already exists. at line: %d\n", id->lineno, name, s->lineno);
    } else if (pass == 1) {
      addSymbol(c, global, name, AST_FUNC_DECL);
    }
  }

}


void handleFormalParameter(ASTNode *c, SymTabScope *localScope, int pass) {
  ASTNode *type = c->children;
  ASTNode *id = type->next;

  setExpTypeWithASTNode(c, type);
  if (pass == 2) {
    SymTabNode *s = lookupSymbol(id->attr, localScope);
    if (s) {
      errorFlag = 1;
      fprintf(stderr, "Error: Cannot declare parameter with name: %s, a parameter with the same name already exists at line: %d, scope: %s\n", id->attr, s->lineno, localScope->name);
    } else {
      addSymbol(c, localScope, id->attr, type->astType);
    }
  }

}

void traverseParseTree(ASTNode *root, SymTabScope *localScope, int pass, int blockLevel, int whileLevel) {
    ASTNode *c = root;

    while (c) {
      int childrenBlockLevel = blockLevel;
      int childrenWhileLevel = whileLevel;
      SymTabScope *childScope = localScope;
      switch (c->astType) {
        case AST_FUNC_DECL:
          handleFuncDecl(c, pass);
          if (pass == 2) {
            childScope = createScope(c->children->next->attr);
            returnFound = 0;
          }
        break;
        case AST_FORMAL:
          handleFormalParameter(c, localScope, pass);
          break;
        case AST_FORMALS:
          if (pass == 2 && c->children && localScope && strcmp(localScope->name, "main") == 0) {
            errorFlag = 1;
            fprintf(stderr, "Error: The main declaration can't have parameters. line: %d\n", c->lineno);
          }
          break;
        case AST_MAIN_DECL:
          handleMainDecl(c, pass);
          if (pass == 2) {
            childScope = createScope(c->children->next->attr);
            returnFound = 0;
          }
          break;
        case AST_ID:
          setExpTypeFromSymbolTable(c, c->attr, localScope);
          break;
        case AST_BLOCK:
          childrenBlockLevel++;
          break;
        case AST_VAR_DECL:
          handleVarDecl(c, localScope, blockLevel, pass);
          break;
        case AST_GLOBAL_VAR_DECL:
          handleGlobalVarDecl(c, pass);
          break;
        case AST_FUNC_CALL:
          checkParametesAndSetFunctionType(c, pass);
          break;
        case AST_BREAK:
          checkIsInWhile(c, whileLevel, pass);
          break;
        case AST_AND:
        case AST_OR:
          checkBoolType(c, pass);
          break;
        case AST_MUL:
        case AST_DIV:
        case AST_MOD:
        case AST_PLUS:
        case AST_SUB:
        case AST_LT:
        case AST_GT:
        case AST_LE:
        case AST_GE:
          checkIntType(c, pass);
          break;
        case AST_ASSIGN:
          setExpTypeWithASTNode(c, c->children->next);
        case AST_EQ:
        case AST_NE:
          checkTypeMatch(c, pass);
          break;
        case AST_RETURN:
          returnFound = 1;
          checkReturnType(c, localScope, pass);
          break;
        case AST_WHILE:
          childrenWhileLevel++;
        case AST_IF:
        case AST_IF_ELSE:
        case AST_NOT:
          checkIfBoolType(c->children, pass);
        break;
        case AST_STMT_EXPR:
          setExpTypeWithASTNode(c, c->children);
          break;
        case AST_USUB:
          checkIfIntType(c->children, pass);
        default:
          {}
      }

      traverseParseTree(c->children, childScope, pass, childrenBlockLevel, childrenWhileLevel);

      checkMissingReturn(c, pass);

      c = c->next;
    }

}


#endif /* SYMANTIC_ANALYSIS */
