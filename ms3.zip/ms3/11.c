
// An if- or while-condition must be of Boolean type.

main() {
  
  if (1) {

  }
}
