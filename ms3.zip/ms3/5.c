
// The main function can't be called.

main() {
  main();

}
