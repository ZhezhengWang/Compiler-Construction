
// An undeclared identifier is used.

main() {
  a = 1;

}
