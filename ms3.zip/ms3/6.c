
// Break statements must be inside a while statement.

main() {
  break;
}

