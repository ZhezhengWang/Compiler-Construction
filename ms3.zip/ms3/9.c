
// A void function can't return a value.

void f() {
  
  return 0;
}


main() {

}
