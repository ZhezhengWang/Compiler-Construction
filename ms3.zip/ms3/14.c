
// The main declaration can't have parameters.

main(int argc) {


}
