
// The number/type of arguments in a function call doesn't match the function's declaration.

void f(int a, int b) {
  
}


main() {
  f(1);

}

