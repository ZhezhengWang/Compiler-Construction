
// Type mismatch for an operator (||, &&, ==, !=, =, <, >, <=, >=, +, - (unary and binary), *, /, %, !).

main() {

  boolean a;
  
  a = 1 && 2;
  

}
