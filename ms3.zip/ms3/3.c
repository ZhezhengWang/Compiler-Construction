
// A local declaration was not in an outermost block.

main() {

  if (true) {
    int a;
  }

}
