
// An identifier is redefined within the same scope.

main() {
  int a;
  int a;


}
