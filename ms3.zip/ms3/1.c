
// No main declaration found.

int abc() {

  return 0;
}
