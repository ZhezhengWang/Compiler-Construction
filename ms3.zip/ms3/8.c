
// No return statement in a non-void function.

int f() {
}

main() {


}
