
// A value returned from a function has the wrong type.


int f() {
  
  return true;
}

main() {

}
