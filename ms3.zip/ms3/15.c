
// A statement expression can only be an assignment or a function invocation.

main() {
  
  1+1;

}
