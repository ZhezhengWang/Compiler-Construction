#include <stdio.h>
#include "parser.h"

YYSTYPE yylval;

extern int yylex();
extern int yylineno;
extern char *yytext;

const char * tokIdToVal(int tok);
const char * tokIdToName(int tok);

int main(int argc, char *argv[]) {
	extern FILE *yyin;

	int ret;
	int line;
  int tok;
	if (argc!=2) {
		fprintf(stderr,"command syntax: %s inputfile.c\n",argv[0]);
		return 1;
	}
	
  yyin=fopen(argv[1],"r");
  printf("[");
  tok = yylex();
  while (tok) {
      printf("Token(%s, %d, %s)", tokIdToName(tok), yylineno, tokIdToVal(tok));    
      tok = yylex();
      if (tok) printf(", ");
  }
  printf("]\n");
  
  fclose(yyin);
  
  
  return 0;
}

const char * tokIdToVal(int tok) {
    switch(tok) {
      case T_NUM: 
      case T_ID:  
      case T_STRING:    return yylval.txt; 
      case T_MUL:       
      case T_DIV:       
      case T_MOD:       
      case T_LT:        
      case T_GT:        
      case T_LE:        
      case T_GE:        
      case T_EQ:        
      case T_NE:        
      case T_NOT:       
      case T_AND:       
      case T_OR:        
      case T_LPAREN:    
      case T_RPAREN:    
      case T_LBRACKET:  
      case T_RBRACKET:  
      case T_SEMICOLON: 
      case T_TRUE:      
      case T_FALSE:     
      case T_BOOLEAN:   
      case T_INT:       
      case T_VOID:      
      case T_IF:        
      case T_WHILE:     
      case T_BREAK:     
      case T_RETURN:    
      case T_COMMENT:   
      case T_NEWLINE:   
      case T_ELSE:      
      case T_ADD:       
      case T_SUB:       
      case T_COMMA:     
      case T_ASSIGN:              return "None";
      case T_LOWER_THAN_ELSE:     return "";
    }
    return "";
}


const char * tokIdToName(int tok) {
    switch(tok) {
      case T_NUM:       return "number";
      case T_ID:        return "id";
      case T_STRING:    return "string";
      case T_MUL:       
      case T_DIV:       
      case T_MOD:       
      case T_LT:        
      case T_GT:        
      case T_LE:        
      case T_GE:        
      case T_EQ:        
      case T_NE:        
      case T_NOT:       
      case T_AND:       
      case T_OR:        
      case T_LPAREN:    
      case T_RPAREN:    
      case T_LBRACKET:  
      case T_RBRACKET:  
      case T_SEMICOLON: 
      case T_TRUE:      
      case T_FALSE:     
      case T_BOOLEAN:   
      case T_INT:       
      case T_VOID:      
      case T_IF:        
      case T_WHILE:     
      case T_BREAK:     
      case T_RETURN:    
      case T_COMMENT:   
      case T_NEWLINE:   
      case T_ELSE:      
      case T_ADD:       
      case T_SUB:       
      case T_COMMA:     
      case T_ASSIGN:              return yytext;
      case T_LOWER_THAN_ELSE:     return "";
    }
    return "";
}
