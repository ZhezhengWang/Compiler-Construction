#ifndef _SYMANTIC_ANALYSIS_H
#define _SYMANTIC_ANALYSIS_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "jmm-types.h"

extern SymTabScope *global;
extern int errorFlag;
extern ASTNode *program;


int yyparse();
void printAST(ASTNode *n, int depth);
void initSysCalls();
void printMainGlobalError(char *name);
void setExpTypeWithASTNode(ASTNode *n, ASTNode *typeNode);
void setExpType(ASTNode *n, ASTNodeExpType type);
int setExpTypeFromSymbolTable(ASTNode *node, SymTabScope *localScope);
void checkParametesAndSetFunctionType(ASTNode *funcCall, int pass);
SymTabScope * createScope(char *name);
unsigned int calcSymbolHash(char *name);
void addSymbol(ASTNode *node, SymTabScope *scope, char *name, ASTNodeType ntype);
SymTabNode * lookupSymbol(char *name, SymTabScope *scope);
void checkMainExists();
void checkMainType(char *sym);
void checkReturn(ASTNode *node);
void checkMissingReturn();
void traverseParseTree(ASTNode *root, SymTabScope *localScope, int pass, int blockLevel, int whileLevel);
ASTNode *createASTNode(ASTNodeType astType, char *attr, int lineno, ASTNodeExpType expType);
ASTNode *addChildren(ASTNode *p, ASTNode *l, ASTNode *r);
ASTNode *addChildren3(ASTNode *p, ASTNode *c1, ASTNode *c2, ASTNode *c3);
ASTNode *addASTNode(ASTNode *p, ASTNode *v);
ASTNode * createFunction(ASTNodeExpType ret, char *name, ASTNodeType param);


#endif /* _SYMANTIC_ANALYSIS_H */
