// Global variable declaration

int g;
int h;

int ff(int a) {
  return a+5;
}

main() {
  h = 1;
  g = h + ff(5);
  printi(g);
}
