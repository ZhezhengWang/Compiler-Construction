// Global variable declaration

void func() {
  
}

main() {
  
}
