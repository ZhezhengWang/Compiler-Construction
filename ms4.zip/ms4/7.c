// Global variable declaration

int g;

main() {
}
