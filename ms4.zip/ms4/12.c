// Global variable declaration
main() {
  if (false) 
    printi(2);
  else
    printi(3);

  if (true) {
    printi(4);
    printi(5);
  }
  else {
    printi(6);
    printi(7);
  }
  printi(8);
}
