// Global variable declaration
main() {
  int a;
  
  a = 0;
  while (a < 5) {
    printi(a);
    a = a + 1;
  } 
    
  printi(7);
}
