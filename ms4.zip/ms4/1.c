
main() {
  prints("Hello");
}
