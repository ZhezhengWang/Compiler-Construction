// Global variable declaration


void func(int a, int b, boolean c) {
  int d;
  int e;
  boolean f;
  
  a = 10;
  b = 20;
  c = true;
  d = 30;
  e = 40;
  f = false;
  
}

main() {
  int g;
  
  func(1,2,true);

  printi(g);
}
