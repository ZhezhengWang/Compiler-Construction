// Global variable declaration

main() {
  int a;
  
}
