// Global variable declaration
int a;
boolean n;

main() {
}
